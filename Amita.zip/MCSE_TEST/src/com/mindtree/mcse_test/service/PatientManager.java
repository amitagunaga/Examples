/**
 * 
 */
package com.mindtree.mcse_test.service;

import java.rmi.ServerException;
import java.util.List;

import com.mindtree.mcse_test.entity.Hospital;
import com.mindtree.mcse_test.entity.Patient;
import com.mindtree.mcse_test.exception.ServiceException;

/**
 * @author m1009614
 * This is the interface class for the Patient Manager Class 
 */
public interface PatientManager {
	public Patient getPatient(String patient_name) throws ServiceException;
	
	public boolean addPatient(Patient patient, String hospital_name) throws ServiceException;
	
	public List<Patient> getAllPatients(String hospital_name) throws ServiceException;
	
	public Hospital getHospital(String hospital_name) throws ServiceException;
	
	public boolean addHospital(Hospital hospital) throws ServiceException;
	
	public List<Hospital> getAllHospitals(String paitient_name) throws ServiceException;
}
