/**
 * 
 */
package com.mindtree.mcse_test.dao;

import java.util.List;

import com.mindtree.mcse_test.entity.Hospital;
import com.mindtree.mcse_test.entity.Patient;
import com.mindtree.mcse_test.exception.DAOException;

/**
 * @author m1009614
 *	 This is the interface class for Hospital DAO class 
 */
public interface HospitalDAO {

	
}
