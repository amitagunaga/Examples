/**
 * 
 */
package com.mindtree.mcse_test.dao;

import java.util.List;

import com.mindtree.mcse_test.entity.Hospital;
import com.mindtree.mcse_test.entity.Patient;
import com.mindtree.mcse_test.exception.DAOException;

/**
 * @author m1009614
 *  This is the interface class for Patient DAO class 
 */
public interface PatientDAO {
	public Patient getPatient(String patient_name) throws DAOException;
	
	public boolean addPatient(Patient patient, String hospital_name) throws DAOException;
	
	public List<Patient> getAllPatients(String hospital_name) throws DAOException;
	
	public Hospital getHospital(String hospital_name) throws DAOException;
	
	public boolean addHospital(Hospital hospital) throws DAOException;
	
	public List<Hospital> getAllHospitals(String paitient_name) throws DAOException;
}
