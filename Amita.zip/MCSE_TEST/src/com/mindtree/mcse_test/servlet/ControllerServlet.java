package com.mindtree.mcse_test.servlet;

import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mindtree.mcse_test.constats.ApplicationConstants;
import com.mindtree.mcse_test.entity.Hospital;
import com.mindtree.mcse_test.entity.Patient;
import com.mindtree.mcse_test.exception.ServiceException;
import com.mindtree.mcse_test.service.PatientManager;
import com.mindtree.mcse_test.util.DateValidator;
import com.mindtree.mcse_test.util.ServiceFactory;

/**
 * This is the Controller servlet which performs tasks for all the actions.
 * 
 *
 */
 public class ControllerServlet extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet {
   static final long serialVersionUID = 1L;   
   static final Logger logger = Logger.getLogger("ControllerServlet.class");
   private ServiceFactory serviceFactory;
   
    /* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public ControllerServlet() {
		super();
	}   	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getParameter("action");
		logger.info("Now processing "+action+" request");
		serviceFactory = ServiceFactory.getInstance();
		RequestDispatcher requestDispatcher;
		
		try {
		if(null != action){
			
				
			if(ApplicationConstants.ADD_HOSPITAL.equals(action)){
				
				/*** Add Hospital Action ***/
				
				PatientManager manager = serviceFactory.getPatientManager();
				Hospital hospital = new Hospital();
				
				readAndValidateInputsforAddHospital(request, response,  hospital);				
								
				// Add hospital
				manager.addHospital(hospital);
				
				request.getSession().setAttribute("result", "Hospital Added Succesfully!");
				requestDispatcher = request.getRequestDispatcher("index.jsp");
				requestDispatcher.forward(request, response);
				
			}else if(ApplicationConstants.PREPARE_FOR_ADD_PATIENT.equals(action)){
				
				/** Preparing for add Patient ***/
				
				// Get all the hospital names to be displayed to the user while adding a new patient details. (Drop Dwon)
				PatientManager manager = serviceFactory.getPatientManager();
				List<Hospital> hospitals =	manager.getAllHospitals("*");
				request.getSession().setAttribute("hospitals", hospitals);
				requestDispatcher = request.getRequestDispatcher("addPatient.jsp");
				requestDispatcher.forward(request, response);
				
			}else if(ApplicationConstants.ADD_PATIENT.equals(action)){
				
				/*** Add Patinet Action ***/
				
				PatientManager manager = serviceFactory.getPatientManager();
				Patient patient = new Patient();
				
				// Read and Validate the inputs
				readAndValidateInputsforAddPatient(request, response,  patient);
				
				String hospital_name = request.getParameter("hospital_name");
				// Add hospital
				manager.addPatient(patient, hospital_name);
				
				request.getSession().setAttribute("result", "Patient Added Succesfully!");
				requestDispatcher = request.getRequestDispatcher("index.jsp");
				requestDispatcher.forward(request, response);
				
			}else if(ApplicationConstants.GET_HOSPITAL.equals(action)){
				
				/*** Get Hospital Details Action ***/
				
				PatientManager manager = serviceFactory.getPatientManager();
				
				// Read and Validate the inputs
				readAndValidateInputsforGetHospital(request, response);
				
				String hospital_name = request.getParameter("hospital_name");
				Hospital hospital = manager.getHospital(hospital_name);
				
				request.getSession().setAttribute("hospital", hospital);
				requestDispatcher = request.getRequestDispatcher("hospitalDetails.jsp");
				requestDispatcher.forward(request, response);
				
			}else if(ApplicationConstants.GET_PATIENT.equals(action)){
				
				/*** Get Patient Details Action ***/
				
				PatientManager manager = serviceFactory.getPatientManager();
				
				// Read and Validate the inputs
				readAndValidateInputsforGetPatient(request, response);

				String patient_name = request.getParameter("patient_name");
				Patient patient = manager.getPatient(patient_name);
				
				request.getSession().setAttribute("patient", patient);
				requestDispatcher = request.getRequestDispatcher("patientDetails.jsp");
				requestDispatcher.forward(request, response);
				
			}else{
				// Invalid action passed.
				logger.info("Invalid action code passed");
				requestDispatcher = request.getRequestDispatcher("error.jsp");
				requestDispatcher.forward(request, response);
			}
		}
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			request.getSession().setAttribute("error", "Invalid Input Please Try Again");
			RequestDispatcher dispatcher = request.getRequestDispatcher("error.jsp");
			dispatcher.forward(request, response);
		}
		
		
	}  	
	
	/**
	 * This method validates the inputs for Get Patient deatils action
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	private void readAndValidateInputsforGetPatient(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		if(null == request.getParameter("patientName")){			
			request.getSession().setAttribute("errors", "Patient Name is Required");
			RequestDispatcher requestDispatcher = request.getRequestDispatcher("addPatient.jsp");
			requestDispatcher.forward(request, response);
		}		
	}
	
	/**
	 * This method validates the inputs for Get Hospital deatils action
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	private void readAndValidateInputsforGetHospital(
			HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if(null == request.getParameter("hospital_name")){			
			request.getSession().setAttribute("errors", "Hospital Name is Required");
			RequestDispatcher requestDispatcher = request.getRequestDispatcher("addPatient.jsp");
			requestDispatcher.forward(request, response);
		}		
	}

	/**
	 * This methdo validates all the input parameters for add patient action.
	 * @param request
	 * @param response
	 * @param patient
	 * @throws ServletException
	 * @throws IOException
	 */
	private void readAndValidateInputsforAddPatient(HttpServletRequest request,
			HttpServletResponse response, Patient patient) throws ServletException, IOException {
		StringBuffer errors = null;
		if(null == request.getParameter("patientName")){
			errors.append("<br>Patient Name is Required");
		}
		if(null == request.getParameter("patientAddress")){
			errors.append("<br>Patient Address is Required");
		}
		if(null == request.getParameter("sex")){
			errors.append("<br>Patient sex is Required");
		}
		
		if(null == request.getParameter("hospitalName")){
			errors.append("<br>hospitalName is Required");
		}
		
		if(null == request.getParameter("patientDOB")){
			errors.append("<br>Patient DOB is Required");
		}
		
		Date date = DateValidator.getFormattedDate(request.getParameter("patientDOB"));
		if(null == date){
			errors.append("<br>Invalid DOB entered");
		}
		
		
		if(null != errors.toString() || "".equals(errors.toString())){
			// Validation error. Return error message
			request.getSession().setAttribute("errors", errors);
			RequestDispatcher requestDispatcher = request.getRequestDispatcher("addPatient.jsp");
			requestDispatcher.forward(request, response);
		}
		patient.setName(request.getParameter("patientName"));
		patient.setAddress(request.getParameter("patientAddress"));
		patient.setSex(request.getParameter("sex"));		
		patient.setDateOfBirth(date);
	}

	/**
	 * This method validates all the input parameters for Add Hospital.
	 * @param request
	 * @param response
	 * @param hospital
	 * @throws ServletException
	 * @throws IOException
	 */
	private void readAndValidateInputsforAddHospital(HttpServletRequest request, HttpServletResponse response, Hospital hospital) throws ServletException, IOException {
		StringBuffer errors = null;
		if(null == request.getParameter("hospitaleName")){
			errors.append("<br>Hospital Name is Required");
		}
		if(null == request.getParameter("hospitalAddress")){
			errors.append("<br>Hospital Address is Required");
		}
		if(null == request.getParameter("specialization")){
			errors.append("<br>Hospital Specialization is Required");
		}
		
		if(null != errors.toString() || "".equals(errors.toString())){
			// Validation error. Return error message
			request.getSession().setAttribute("errors", errors);
			RequestDispatcher requestDispatcher = request.getRequestDispatcher("addHospital.jsp");
			requestDispatcher.forward(request, response);
		}
		hospital.setName(request.getParameter("hospitaleName"));
		hospital.setAddress(request.getParameter("hospitalAddress"));
		hospital.setSpecialization(request.getParameter("specialization"));		
				
	}

	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}   	  	    
}