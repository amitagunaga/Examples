/**
 * 
 */
package com.mindtree.mcse_test.serviceImpl;

import java.rmi.ServerException;
import java.util.List;

import com.mindtree.mcse_test.dao.PatientDAO;
import com.mindtree.mcse_test.daoImpl.PatientDAOImpl;
import com.mindtree.mcse_test.entity.Hospital;
import com.mindtree.mcse_test.entity.Patient;
import com.mindtree.mcse_test.exception.DAOException;
import com.mindtree.mcse_test.exception.ServiceException;
import com.mindtree.mcse_test.service.PatientManager;

/**
 * @author m1009614
 * This is the implementation class for the Patient Manager class
 */
public class PatientManagerImpl implements PatientManager{

	public boolean addHospital(Hospital hospital) throws ServiceException {
		PatientDAO patientDAO = new PatientDAOImpl();
		try {
			return patientDAO.addHospital(hospital);
		} catch (DAOException e) {
			throw new ServiceException(e.getMessage());
		}		
	}

	public boolean addPatient(Patient patient, String hospital_name)
			throws ServiceException {
		PatientDAO patientDAO = new PatientDAOImpl();
		
		try {
			return patientDAO.addPatient(patient, hospital_name);
		} catch (DAOException e) {
			throw new ServiceException(e.getMessage());
		}
	}

	public List<Hospital> getAllHospitals(String paitient_name)
			throws ServiceException {
		PatientDAO patientDAO = new PatientDAOImpl();
		
		try {
			return patientDAO.getAllHospitals(paitient_name);
		} catch (DAOException e) {
			throw new ServiceException(e.getMessage());
		}
	}

	public List<Patient> getAllPatients(String hospital_name)
			throws ServiceException {
		PatientDAO patientDAO = new PatientDAOImpl();
		try {
			patientDAO.getAllPatients(hospital_name);
		} catch (DAOException e) {
			throw new ServiceException(e.getMessage());
		}
		return null;
	}

	public Hospital getHospital(String hospital_name) throws ServiceException {
		PatientDAO patientDAO = new PatientDAOImpl();
		
		try {
			return patientDAO.getHospital(hospital_name);
		} catch (DAOException e) {
			throw new ServiceException(e.getMessage());
		}
	}

	public Patient getPatient(String patient_name) throws ServiceException {
		PatientDAO patientDAO = new PatientDAOImpl();
		
		try {
			return patientDAO.getPatient(patient_name);
		} catch (DAOException e) {
			throw new ServiceException(e.getMessage());
		}
	}

}
