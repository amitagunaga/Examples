/**
 * 
 */
package com.mindtree.mcse_test.exception;

/**
 * @author m1009614
 * This is the exception thrown by the service layer.
 */
public class ServiceException extends Exception {

	/**
	 * 
	 */
	public ServiceException() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param arg0
	 * @param arg1
	 */
	public ServiceException(String message, Throwable throwable) {
		super(message, throwable);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param arg0
	 */
	public ServiceException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param arg0
	 */
	public ServiceException(Throwable throwable) {
		super(throwable);
		// TODO Auto-generated constructor stub
	}

}
