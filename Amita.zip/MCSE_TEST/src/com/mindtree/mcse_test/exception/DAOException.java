/**
 * 
 */
package com.mindtree.mcse_test.exception;

/**
 * @author m1009614
 * This is the exception, which will be  thrown by the DAO layer. 
 */
public class DAOException extends Exception {

	/**
	 * 
	 */
	public DAOException() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param arg0
	 * @param arg1
	 */
	public DAOException(String message, Throwable throwable) {
		super(message, throwable);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param arg0
	 */
	public DAOException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param arg0
	 */
	public DAOException(Throwable throwable) {
		super(throwable);
		// TODO Auto-generated constructor stub
	}
	

}
