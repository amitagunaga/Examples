/**
 * 
 */
package com.mindtree.mcse_test.entity;

import java.util.Date;
import java.util.List;

/**
 * @author m1009614
 *This is the value object for Patient entity 
 */
public class Patient {
	private String name;
	private String sex;
	private String address;
	private Date dateOfBirth;
	private List<Hospital> hospitals;
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the sex
	 */
	public String getSex() {
		return sex;
	}
	/**
	 * @param sex the sex to set
	 */
	public void setSex(String sex) {
		this.sex = sex;
	}
	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}
	/**
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}
	/**
	 * @return the dateOfBirth
	 */
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	/**
	 * @param dateOfBirth the dateOfBirth to set
	 */
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	/**
	 * @return the hospitals
	 */
	public List<Hospital> getHospitals() {
		return hospitals;
	}
	/**
	 * @param hospitals the hospitals to set
	 */
	public void setHospitals(List<Hospital> hospitals) {
		this.hospitals = hospitals;
	}
	
}
