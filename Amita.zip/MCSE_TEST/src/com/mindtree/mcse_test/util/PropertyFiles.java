/**
 * 
 */
package com.mindtree.mcse_test.util;

import java.util.ResourceBundle;

/**
 * @author m1009614
 *  This class is used to read message values from property files.
 */
public class PropertyFiles {
	private static ResourceBundle resourceBundle = ResourceBundle.getBundle("messages_en.properties");
	
	/**
	 * This method provides the message values for the given message key.
	 * @param key
	 * @return
	 */
	public static String getMessageValue(String key){
		return resourceBundle.getString(key);
	}
}
