/**
 * 
 */
package com.mindtree.mcse_test.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author m1009614
 *
 */
public class DateValidator {
	private static SimpleDateFormat simpleDateFormat;
	
	/**
	 * This method converts string date to java util date.
	 * If invalid date format is sent, then returns null.
	 * @param date
	 * @return
	 */
	public static Date getFormattedDate(String date){
		simpleDateFormat = new SimpleDateFormat("DD/MM/YYYY");
		Date date2;
		try {
			date2 = simpleDateFormat.parse(date);
			return date2;
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
}
