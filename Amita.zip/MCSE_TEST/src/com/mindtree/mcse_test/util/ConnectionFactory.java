/**
 * 
 */
package com.mindtree.mcse_test.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.mindtree.mcse_test.constats.DBConstants;
import com.mindtree.mcse_test.exception.DAOException;

/**
 * @author m1009614
 * This is the factory class for the DB Connections
 */
public class ConnectionFactory {
	private static Connection connection;
	private static Logger logger = Logger.getLogger("ConnectionFactory.java");
	
	/**
	 * This is the method which gives DB Connections
	 * @return
	 * @throws DAOException
	 */
	public static Connection getConnection() throws DAOException{		
		if(null != connection){
			return connection;
		}else{
			logger.info("Creating a new connection");
			try {
				Class.forName(DBConstants.DRIVER_CLASS.getValue());
				connection = DriverManager.getConnection(DBConstants.CONNECTION_URL.getValue(), 
						DBConstants.DB_USERNAME.getValue(), DBConstants.DB_PASSWORD.getValue());
			} catch (ClassNotFoundException e) {
				logger.log(Level.SEVERE, "Invalid Driver Class specified");
				throw new DAOException();
			} catch (SQLException e) {
				logger.log(Level.SEVERE, "DB Connection failed");				
				throw new DAOException(PropertyFiles.getMessageValue("error.failedToConnect"));
			}
			return connection;
		}
	}
	
	/**
	 * This is the method used to close the DB Connections.
	 * @param connection
	 * @return
	 */
	public static boolean closeConnection(Connection connection){
		if(null != connection){
			logger.info("Now closing the connection");
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return true;
		}
		return false;
	}
}
