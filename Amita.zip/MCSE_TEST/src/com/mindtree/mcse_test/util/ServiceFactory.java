package com.mindtree.mcse_test.util;

import com.mindtree.mcse_test.service.PatientManager;
import com.mindtree.mcse_test.serviceImpl.PatientManagerImpl;

public class ServiceFactory {
	private static ServiceFactory factory;
	
	/**
	 * Provides the Service Factory instance
	 * @return
	 */
	public static ServiceFactory getInstance(){
		if(null != factory){
			return factory;
		}else{
			return new ServiceFactory();
		}
	}
	
	/**
	 * Provides an instance of Patient manager class
	 * @return
	 */
	public PatientManager getPatientManager(){
		return new PatientManagerImpl();
	}	
	
}
