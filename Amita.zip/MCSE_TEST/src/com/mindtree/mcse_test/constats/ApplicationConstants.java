/**
 * 
 */
package com.mindtree.mcse_test.constats;

/**
 * @author m1009614
 *
 */
public enum ApplicationConstants {
	ADD_PATIENT("addPatient"),
	ADD_HOSPITAL("addHospital"),
	GET_PATIENT("getPatient"),
	GET_HOSPITAL("getHospital"),
	PREPARE_FOR_ADD_PATIENT("prepareForAddPatient");
	
	private ApplicationConstants(String message){
		this.message = message;
	}
	private String message;
	
	public String getValue(){
		return this.message;
	}
}
