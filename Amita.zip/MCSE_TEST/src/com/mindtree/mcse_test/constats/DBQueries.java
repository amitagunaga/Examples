/**
 * 
 */
package com.mindtree.mcse_test.constats;

/**
 * @author m1009614
 * This class contains all the DB queries used in this project.
 */
public interface DBQueries {
	public static String ADD_HOSPITAL_QUERY = "insert into HOSPITAL (hospital_name, hospital_address, hospital_specialization) values (?,?,?)";
	public static String ADD_PATIENT_QUERY = "insert into PATIENT (patient_name, patient_sex, patient_dob, patient_address) values (?, ?, ?, ?)";
	public static String ADD_PATIENT_HOSPITAL = "insert into PATIENT_HOSPITAL (patient_name, hospital_name) values (?, ?)";
	public static String GET_PATIENT = "select * from PATIENT where patient_name = (?)";
	public static String GET_HOSPITAL = "select * from HOSPITAL where hospital_name = (?)";
	public static String GET_ALL_PATIENTS = "select * from PATIENT p, PATIENT_HOSPITAL ph where p.patient_name = ph.patient_name and ph.hospital_name = (?)";
	public static String GET_ALL_HOSPITALS = "select * from HOSPITAL h, PATIENT_HOSPITAL ph where h.hospital_name = ph.hospital_name and ph.patient_name = (?)";
}

/*
create table HOSPITAL{
	hospital_name 				VARCHAR2(10) not null primary key,
	hospital_address 			VARCHAR2(25) not null,
	hospital_specialization 	VARCHAR2(10) not null
}

create table PATIENT{
	patient_name VARCHAR2(10) not null primary key,
	patient_sex VARCHAR2(1) not null,
	patient_dob DATE not null,
	patient_address VARCHAR2(25) not null
}

create table HOSPITAL_PATIENT{
	patient_name not null,
	hospital_name not null,
	primary key(patient_name, hospital_name)
}
*/