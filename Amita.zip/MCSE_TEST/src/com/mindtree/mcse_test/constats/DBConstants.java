/**
 * 
 */
package com.mindtree.mcse_test.constats;

/**
 * @author m1009614
 * This enum holds all the DB Connection Constants
 */
public enum DBConstants {
	DRIVER_CLASS("com.mysql.jdbc.driver"),
	CONNECTION_URL("jdbc/mysql/localhost:8080/"),
	DB_USERNAME("root"),
	DB_PASSWORD("root");
	
	private DBConstants(String value) {
		this.value = value;
	}
	
	private String value;
	
	public String getValue() {
		return this.value;
	}

}
