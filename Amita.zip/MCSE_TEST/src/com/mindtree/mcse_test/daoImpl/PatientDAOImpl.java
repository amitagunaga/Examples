/**
 * 
 */
package com.mindtree.mcse_test.daoImpl;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.mindtree.mcse_test.constats.DBQueries;
import com.mindtree.mcse_test.dao.PatientDAO;
import com.mindtree.mcse_test.entity.Hospital;
import com.mindtree.mcse_test.entity.Patient;
import com.mindtree.mcse_test.exception.DAOException;
import com.mindtree.mcse_test.util.ConnectionFactory;
import com.mindtree.mcse_test.util.PropertyFiles;

/**
 * @author m1009614
 *
 */
public class PatientDAOImpl implements PatientDAO {
	private Logger logger = Logger.getLogger("PatientDAO.class");
	/* (non-Javadoc)
	 * @see com.mindtree.mcse_test.dao.PatientDAO#addPatient(com.mindtree.mcse_test.entity.Patient, java.lang.String)
	 * This method adds a new patient to the given hospital 
	 */
	public boolean addPatient(Patient patient, String hospital_name)
			throws DAOException {
		logger.info("Now adding a new Patient");
		boolean isNewPatient;
		boolean result;
		Connection connection = ConnectionFactory.getConnection();
		try {
			// Check if the patient is already added to the PATIENT table.
			PreparedStatement preparedStatement = connection.prepareStatement(DBQueries.GET_PATIENT);
			preparedStatement.setString(0, patient.getName());
			isNewPatient = !preparedStatement.execute();
			
			if(isNewPatient){
				// New Patient? Add the patient to PATIENT table
				preparedStatement = connection.prepareStatement(DBQueries.ADD_PATIENT_QUERY);
				preparedStatement.setString(0, patient.getName());
				preparedStatement.setString(1, patient.getSex());
				Date date = new Date(patient.getDateOfBirth().getTime());
				preparedStatement.setDate(2, date);
				preparedStatement.setString(3, patient.getAddress());			
				result = preparedStatement.execute();
			}			
			
			// Now update the intermediate table
			preparedStatement = connection.prepareStatement(DBQueries.ADD_PATIENT_HOSPITAL);
			preparedStatement.setString(0, patient.getName());
			preparedStatement.setString(1, hospital_name);
			result = preparedStatement.execute();
			
			logger.info("Patient added succesfully");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new DAOException(PropertyFiles.getMessageValue("error.patient.failedToAdd"));
		}
		return result;
	}

	/* (non-Javadoc)
	 * @see com.mindtree.mcse_test.dao.PatientDAO#getAllPatients(java.lang.String)
	 * This method returns all the patients of a given hospital
	 */
	public List<Patient> getAllPatients(String hospital_name)
			throws DAOException {
		logger.info("Now retreving list of Patient");
		
		Connection connection = ConnectionFactory.getConnection();		
		List<Patient> patients = new ArrayList<Patient>();
		try {
			PreparedStatement preparedStatement = connection.prepareStatement(DBQueries.GET_ALL_PATIENTS);
			preparedStatement.setString(0, hospital_name);
			
			ResultSet resultSet = preparedStatement.executeQuery();
			while(resultSet.next()){
				Patient patient = new Patient();
				
				patient.setName(resultSet.getString("patient_name"));
				patient.setSex(resultSet.getString("patient_sex"));
				patient.setAddress(resultSet.getString("patient_address"));				
				java.util.Date date = new java.util.Date(resultSet.getDate("patient_dob").getTime());
				patient.setDateOfBirth(date);
				
				patients.add(patient);
				logger.info("All patients retreved succesfully!");
			}
			return patients;
		} catch (SQLException e) {
			logger.log(Level.SEVERE, "Failed to get all the patients");
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new DAOException(PropertyFiles.getMessageValue("error.patient.failedToGetAllPatients"));
		}		
	}

	/* (non-Javadoc)
	 * @see com.mindtree.mcse_test.dao.PatientDAO#getPatient()
	 * This method returns the given patient details
	 */
	public Patient getPatient(String patient_name) throws DAOException {
		logger.info("Now retreving a Patient");
		Connection connection = ConnectionFactory.getConnection();
		try {
			PreparedStatement preparedStatement = connection.prepareStatement(DBQueries.GET_PATIENT);
			preparedStatement.setString(0, patient_name);
			
			ResultSet resultSet = preparedStatement.executeQuery();
			Patient patient = new Patient();
			if(resultSet.next()){
				patient.setName(resultSet.getString("patient_name"));
				patient.setAddress(resultSet.getString("patient_address"));
				patient.setSex(resultSet.getString("patient_sex"));
				java.util.Date date = new java.util.Date(resultSet.getDate("patient_dob").getTime());
				patient.setDateOfBirth(date);
			}
			logger.info("Patient retrieved succesfully");
			
			// Get all hspitals this patient is allocated to.
			patient.setHospitals(getAllHospitals(patient.getName()));
			
			return patient;
		} catch (SQLException e) {
			e.printStackTrace();
			logger.log(Level.SEVERE, "Failed to retreive patient");
			throw new DAOException(PropertyFiles.getMessageValue("error.patient.getPatient"));
		}
	}
	
	/**
	 * This method adds the given hospital to the table.
	 */
	public boolean addHospital(Hospital hospital) throws DAOException {
		logger.info("Now adding a new Hospital");
		boolean result;
		Connection connection = ConnectionFactory.getConnection();
		try {
			PreparedStatement preparedStatement = connection.prepareStatement(DBQueries.ADD_HOSPITAL_QUERY);
			preparedStatement.setString(0, hospital.getName());
			preparedStatement.setString(1, hospital.getAddress());			
			preparedStatement.setString(3, hospital.getSpecialization());			
			result = preparedStatement.execute();			
			
			logger.info("Hospital added succesfully");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new DAOException(PropertyFiles.getMessageValue("error.hospital.failedToAdd"));
		}
		return result;
	}
	
	/**
	 * This method gives the details of all the hospitals for the given patient
	 */	
	public List<Hospital> getAllHospitals(String patient_name)
			throws DAOException {
		logger.info("Now retreving list of Hospital");
		
		Connection connection = ConnectionFactory.getConnection();		
		List<Hospital> hospitals = new ArrayList<Hospital>();
		try {
			PreparedStatement preparedStatement = connection.prepareStatement(DBQueries.GET_ALL_HOSPITALS);
			preparedStatement.setString(0, patient_name);
			
			ResultSet resultSet = preparedStatement.executeQuery();
			while(resultSet.next()){
				Hospital hospital = new Hospital();
				
				hospital.setName(resultSet.getString("hospital_name"));
				hospital.setSpecialization(resultSet.getString("hospital_specialization"));
				hospital.setAddress(resultSet.getString("hospital_address"));				
				
				hospitals.add(hospital);
				logger.info("All Hospital retreved succesfully!");
			}
			return hospitals;
		} catch (SQLException e) {
			logger.log(Level.SEVERE, "Failed to get all the Hospital");
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new DAOException(PropertyFiles.getMessageValue("error.hospital.failedToGetAllHospitals"));
		}		
	}
	
	/**
	 * This method gives the details of a given hospital
	 */
	public Hospital getHospital(String hospital_name) throws DAOException {
		logger.info("Now retreving a Hospital");
		Connection connection = ConnectionFactory.getConnection();
		try {
			PreparedStatement preparedStatement = connection.prepareStatement(DBQueries.GET_HOSPITAL);
			preparedStatement.setString(0, hospital_name);
			
			ResultSet resultSet = preparedStatement.executeQuery();
			Hospital hospital = new Hospital();
			if(resultSet.next()){
				hospital.setName(resultSet.getString("hospital_name"));
				hospital.setAddress(resultSet.getString("hospital_address"));
				hospital.setSpecialization("hospital_specialization");
			}
			logger.info("Hospital retrieved succesfully");
			
			// Get all hspitals this patient is allocated to.
			hospital.setPatients(getAllPatients(hospital.getName()));
			
			return hospital;
		} catch (SQLException e) {
			e.printStackTrace();
			logger.log(Level.SEVERE, "Failed to retreive Hospital");
			throw new DAOException(PropertyFiles.getMessageValue("error.hospital.getHospital"));
		}
	}

}
