-----------------------------------------------------
// Hospital Table
create table HOSPITAL{
	hospital_name 				VARCHAR2(10) not null 	primary key,
	hospital_address 			VARCHAR2(25) not null,
	hospital_specialization 	VARCHAR2(10) not null
}

// Patinet Table
create table PATIENT{
	patient_name 		VARCHAR2(10) 	not null 	primary key,
	patient_sex 		VARCHAR2(1) 	not null,
	patient_dob 		DATE 			not null,
	patient_address 	VARCHAR2(25)	not null
}

// Common Table
create table HOSPITAL_PATIENT{
	patient_name 		not null,
	hospital_name 		not null,
	primary key(patient_name, hospital_name)
}