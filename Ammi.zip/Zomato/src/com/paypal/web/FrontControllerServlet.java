package com.paypal.web;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.paypal.dao.ZomatoDao;
import com.paypal.dao.ZomatoDaoJdbcImpl;
import com.paypal.exception.ApplicationException;
import com.paypal.exception.DaoException;
import com.paypal.model.Parameter;
import com.paypal.model.Ratings;
import com.paypal.model.Restaurant;
import com.paypal.model.Review;

/**
 * Servlet implementation class FrontControllerServlet
 */
@WebServlet("/FrontControllerServlet")
public class FrontControllerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private static final String GET_ADD_RESTAURANT_FORM="addRestaurantForm.action";
	private static final String ADD_RESTAURANT_TO_DB="addRestaurantToDB.action";
	private static final String GET_ADD_REVIEWS_FORM="addReviewsToRestaurantForm.action";
	private static final String ADD_REVIEWS_TO_DB="addReviewsToDB.action";
	private static final String GET_SEARCH_OPTIONS_FORM="searchFormPage.action";
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FrontControllerServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		process(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		process(request, response);
	}

	private void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String uri =  request.getRequestURI();
		if(uri.endsWith(GET_ADD_RESTAURANT_FORM)) {
			getAddRestaurantFormAction(request,response);
		}
		else if(uri.endsWith(ADD_RESTAURANT_TO_DB)) {
			getAddARestaurantToDBAction(request, response);
		}
		else if(uri.endsWith(GET_ADD_REVIEWS_FORM)) {
			getAddReviewsToRestaurantForm(request, response);
		}
		else if(uri.endsWith(ADD_REVIEWS_TO_DB)){
			getAddReviewsToDBAction(request,response);
		}
		else if(uri.endsWith(GET_SEARCH_OPTIONS_FORM)) {
			getSearchOptionForm(request,response);
		}
	}
	
	private void getAddRestaurantFormAction(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String forwardPath = "addRestaurantForm.jsp";
		RequestDispatcher rd = request.getRequestDispatcher(forwardPath);
		rd.forward(request, response);
	}
	private void getAddARestaurantToDBAction(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ZomatoDao dao = new ZomatoDaoJdbcImpl();
		String forwardPath = "successPage.jsp";
		
		Restaurant restaurant = new Restaurant();
		restaurant.setName(request.getParameter("name"));
		restaurant.setAddress(request.getParameter("address"));
		
		try {
			dao.addARestaurant(restaurant);
		} catch (ApplicationException e) {
			e.printStackTrace();
			forwardPath = "errorPage.jsp";
			request.setAttribute("errorMess", e.getMessage());
		} catch (DaoException e) {
			e.printStackTrace();
			forwardPath = "errorPage.jsp";
			request.setAttribute("errorMess", e.getMessage());
		}
		request.setAttribute("successMess", "Restaurant "+restaurant.getName()+" successfully added");
		RequestDispatcher rd = request.getRequestDispatcher(forwardPath);
		rd.forward(request, response);
	}
	
	private void getAddReviewsToRestaurantForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String forwardPath = "ReviewARestaurant.jsp";
		ZomatoDao dao = new ZomatoDaoJdbcImpl();
		try {
			List<Restaurant> restaurants = dao.getAllRestaurants();
			List<Parameter> parameters = dao.getAllParameters();
			List<Ratings> ratings = dao.getAllRatings();
			request.setAttribute("restaurants", restaurants);
			request.setAttribute("parameters", parameters);
			request.setAttribute("ratings", ratings);
		} catch (DaoException e) {
			e.printStackTrace();
			forwardPath = "errorPage.jsp";
			request.setAttribute("errorMess", e.getMessage());
		}
		RequestDispatcher rd = request.getRequestDispatcher(forwardPath);
		rd.forward(request, response);
	}
	
	private void getAddReviewsToDBAction(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String forwardPath = "successPage.jsp";
		ZomatoDao dao = new ZomatoDaoJdbcImpl();
		
		try {
			Review r = new Review();
			r.setName(request.getParameter("name"));
			r.setRestaurant(request.getParameter("restaurant"));
			r.setParameter(request.getParameter("parameters"));
			r.setRatingId(Integer.parseInt(request.getParameter("ratings")));
			r.setReviewDiscription(request.getParameter("review"));
			
			dao.addReview(r);
			request.setAttribute("successMess", "Review successfully added to "+r.getRestaurant()+" by "+r.getName()+"....... Thank you!!");
		} catch (ApplicationException e) {
			e.printStackTrace();
			request.setAttribute("errorMess",e.getMessage());
			forwardPath="errorPage.jsp";
		} catch (DaoException e) {
			e.printStackTrace();
			request.setAttribute("errorMess",e.getMessage());
			forwardPath="errorPage.jsp";
		}
		RequestDispatcher dis=request.getRequestDispatcher(forwardPath);
		dis.forward(request, response);
	}

	private void getSearchOptionForm(HttpServletRequest request, HttpServletResponse response) {
		String forwardPath="searchForm.jsp";
		RequestDispatcher dis=request.getRequestDispatcher(forwardPath);
		//dis.forward(request, response);
	}
}
