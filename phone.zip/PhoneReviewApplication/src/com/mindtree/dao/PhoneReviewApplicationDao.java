package com.mindtree.dao;

import java.util.List;

import com.mindtree.entity.Phone;
import com.mindtree.entity.Review;
import com.mindtree.exceptions.ApplicationException;
import com.mindtree.exceptions.DaoException;

public interface PhoneReviewApplicationDao {
	public void addPhone(Phone phone) throws DaoException, ApplicationException;
	
	public List<Phone> getAllModelsForABrand(String brand) throws DaoException;
	
	public void addReview(Review review) throws DaoException, ApplicationException;
	
	public List<Phone> getTopRatedPhones() throws DaoException;
	
	public List<Review> searchPhones(String brand,Integer weight,Integer price,boolean currentlyAvailable);
	
}
