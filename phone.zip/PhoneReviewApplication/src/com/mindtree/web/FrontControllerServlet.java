package com.mindtree.web;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mindtree.dao.PhoneReviewApplicationDao;
import com.mindtree.dao.PhoneReviewApplicationDaoJdbcImpl;
import com.mindtree.entity.Phone;
import com.mindtree.entity.Review;
import com.mindtree.exceptions.ApplicationException;
import com.mindtree.exceptions.DaoException;

public class FrontControllerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private static final String GET_ADD_PHONE_FORM="addPhoneForm.action";
	private static final String ADD_PHONE_TO_DB="addPhoneToDB.action";
	private static final String GET_ADD_REVIEWS_TO_PHONE_FORM="reviewPhoneForm.action";
	private static final String GRT_MODELS_FOR_BRAND="getModelForBrand.action";
	private static final String ADD_REVIEWS_TO_DB="addReviewsToDB.action";
	private static final String GET_SEARCH_OPTIONS_FORM="searchFormPage.action";
	private static final String GET_TOP_RATED_PHONES="topRatedPhonesSearch.action";
	private static final String GET_SEARCH_CRITERIA_FORM="getSearchCriteriaForm.action";
	private static final String SEARCH_PHONES="searchPhones.action";
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		process(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		process(request,response);
	}
	

	private void process(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		String uri=request.getRequestURI();
		if(uri.endsWith(GET_ADD_PHONE_FORM)){
			getAddPhoneFormAction(request,response);
		}	
		else if(uri.endsWith(ADD_PHONE_TO_DB)){
			getAddAPhoneToDBAction(request,response);
		}
		else if(uri.endsWith(GET_ADD_REVIEWS_TO_PHONE_FORM)){
			getAddReviewsToPhoneFormAction(request,response);
		}
		else if(uri.endsWith(GRT_MODELS_FOR_BRAND)){
			getModelsForBrand(request,response);
		}
		else if(uri.endsWith(ADD_REVIEWS_TO_DB)){
			addReviewsAction(request,response);
		}
		else if(uri.endsWith(GET_SEARCH_OPTIONS_FORM)){
			getSearchOptionForm(request,response);
		}
		else if(uri.endsWith(GET_TOP_RATED_PHONES)){
			getTopRatedPhonesAction(request,response);
		}
		else if(uri.endsWith(GET_SEARCH_CRITERIA_FORM)){
			getSearchCriteriaFormAction(request,response);
		}
		else if(uri.endsWith(SEARCH_PHONES)){
			searchPhonesAction(request,response);
		}
		else{
			response.sendError(404,"Requested URL not found");
		}
	}

	private void searchPhonesAction(HttpServletRequest request,
			HttpServletResponse response) {
		
		PhoneReviewApplicationDao dao=new PhoneReviewApplicationDaoJdbcImpl();
		
		List<Review> phonesRes;
		
		String brand=request.getParameter("brand");
		String weight=request.getParameter("weight");
		String price=request.getParameter("price");
		String currentlyAvailable=request.getParameter("ca");
//		List<String> formFactor=new ArrayList<String>();
//		List<String> connectivity=new ArrayList<String>();
		
		boolean ca;
		
		if(brand.equals("")){
			brand=null;
		}
		Integer w=null;
		if(weight!=null || !weight.equals("")){
			w=new Integer(weight);
		}
		
		Integer p=null;
		if(price!=null || !price.equals("")){
			p=new Integer(price);
		}
		
		System.out.println("curr ava :"+currentlyAvailable);
		if(currentlyAvailable==null){
			ca=false;
		}
		else{
			ca=true;
		}
		
		phonesRes=dao.searchPhones(brand, w, p, ca);
		for(Review p1 : phonesRes){
			System.out.println(p1.getBrand());
			System.out.println(p1.getModel());
		}
		
		
	}

	private void getSearchCriteriaFormAction(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String forwardPath="SearchCriteriaForm.jsp";
		RequestDispatcher dis=request.getRequestDispatcher(forwardPath);
		dis.forward(request, response);
	}

	private void getTopRatedPhonesAction(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String forwardPath="dispTopRatedPhones.jsp";
		PhoneReviewApplicationDao dao=new PhoneReviewApplicationDaoJdbcImpl();
		
		try{
			List<Phone> phones=dao.getTopRatedPhones();
			request.setAttribute("phones", phones);
		}
		catch (DaoException e) {
			e.printStackTrace();
			request.setAttribute("errorMess",e.getMessage());
			forwardPath="errorPage.jsp";
		}
		catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("errorMess",e.getMessage());
			forwardPath="errorPage.jsp";
		}
		RequestDispatcher dis=request.getRequestDispatcher(forwardPath);
		dis.forward(request, response);
	}

	private void getSearchOptionForm(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String forwardPath="searchForm.jsp";
		RequestDispatcher dis=request.getRequestDispatcher(forwardPath);
		dis.forward(request, response);
	}

	private void addReviewsAction(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		PhoneReviewApplicationDao dao=new PhoneReviewApplicationDaoJdbcImpl();
		String forwardPath="successPage.jsp";
		try{
			Review review=new Review();
			review.setModel(request.getParameter("model"));
			review.setBrand(request.getParameter("brand"));
			review.setDesignRating(Integer.parseInt(request.getParameter("designRating")));
			review.setFeaturesRating(Integer.parseInt(request.getParameter("featuresRating")));
			review.setPerformanceRating(Integer.parseInt(request.getParameter("performanceRating")));
			review.setReview(request.getParameter("review"));
			
			dao.addReview(review);
		
			request.setAttribute("successMess", "Review successfully added to phone "+review.getModel());
			
		}
		catch (DaoException e) {
			e.printStackTrace();
			request.setAttribute("errorMess",e.getMessage());
			forwardPath="errorPage.jsp";
		}
		catch (ApplicationException e) {
			e.printStackTrace();
			request.setAttribute("errorMess",e.getMessage());
			forwardPath="errorPage.jsp";
		}
		catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("errorMess",e.getMessage());
			forwardPath="errorPage.jsp";
		}
		RequestDispatcher dis=request.getRequestDispatcher(forwardPath);
		dis.forward(request, response);
	}
				

	private void getModelsForBrand(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String forwardPath="DispModels.jsp";
		String brand=request.getParameter("brand");
		
		PhoneReviewApplicationDao dao=new PhoneReviewApplicationDaoJdbcImpl();
		try {
			List<Phone> phonesForModels=dao.getAllModelsForABrand(brand);
			request.setAttribute("resPhones", phonesForModels);
//			for(Phone p : phonesForModels){
//				System.out.println("Models : "+p.getModel());
//			}
		} catch (DaoException e) {
			e.printStackTrace();
			request.setAttribute("errorMess",e.getMessage());
			forwardPath="errorPage.jsp";
		}
		RequestDispatcher dis=request.getRequestDispatcher(forwardPath);
		dis.forward(request, response);
	}

	private void getAddReviewsToPhoneFormAction(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String forwardPath="ReviewAPhone.jsp";
		RequestDispatcher dis=request.getRequestDispatcher(forwardPath);
		dis.forward(request, response);
	}

	private void getAddAPhoneToDBAction(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		PhoneReviewApplicationDao dao=new PhoneReviewApplicationDaoJdbcImpl();
		String forwardPath="successPage.jsp";
		String connectivityS="";
		String connectivitySF="";
		try{
			Phone phone=new Phone();
			phone.setModel(request.getParameter("model"));
			phone.setBrand(request.getParameter("brand"));
			phone.setFormFactor(request.getParameter("formFactor"));
			phone.setWeight(Integer.parseInt(request.getParameter("weight")));
			//phone.setConnectivity(request.getParameter("connectivity"));
			String[] connectivity=request.getParameterValues("connectivity");
			for(int i=0;i<connectivity.length;i++){
				connectivityS += connectivity[i]+",";
			}
			connectivitySF=connectivityS.substring(0,(connectivityS.length()-1));
			System.out.println(connectivitySF);
			phone.setConnectivity(connectivitySF);
			phone.setPrice(Integer.parseInt(request.getParameter("price")));
//			phone.setAvailableFrom(availableFrom)
			phone.setDescription(request.getParameter("description"));
			String availableFromS=request.getParameter("availableFrom");
			SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
			Date availableFromU=sdf.parse(availableFromS);
			phone.setAvailableFrom(availableFromU);
			
			dao.addPhone(phone);
		
			request.setAttribute("successMess", "Phone "+phone.getModel()+" successfully added...");
			
		}
		catch (ParseException e) {
			e.printStackTrace();
			request.setAttribute("errorMess", "Error while parsing date");
			forwardPath="errorPage.jsp";
		}
		catch (DaoException e) {
			e.printStackTrace();
			request.setAttribute("errorMess",e.getMessage());
			forwardPath="errorPage.jsp";
		}
		catch (ApplicationException e) {
			e.printStackTrace();
			request.setAttribute("errorMess",e.getMessage());
			forwardPath="errorPage.jsp";
		}
		catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("errorMess",e.getMessage());
			forwardPath="errorPage.jsp";
		}
		RequestDispatcher dis=request.getRequestDispatcher(forwardPath);
		dis.forward(request, response);
	}

	private void getAddPhoneFormAction(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String forwardPath="addPhone.jsp";
		RequestDispatcher dis=request.getRequestDispatcher(forwardPath);
		dis.forward(request, response);
	}
}
