package com.mindtree.entity;

import java.io.Serializable;

public class Review implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private String model;
	private String brand;
	private Integer designRating;
	private Integer featuresRating;
	private Integer performanceRating;
	private String review;
	
	public Review() {
		// TODO Auto-generated constructor stub
	}

	public Review(String model, String brand, Integer designRating,
			Integer featuresRating, Integer performanceRating, String review) {
		super();
		this.model = model;
		this.brand = brand;
		this.designRating = designRating;
		this.featuresRating = featuresRating;
		this.performanceRating = performanceRating;
		this.review = review;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public Integer getDesignRating() {
		return designRating;
	}

	public void setDesignRating(Integer designRating) {
		this.designRating = designRating;
	}

	public Integer getFeaturesRating() {
		return featuresRating;
	}

	public void setFeaturesRating(Integer featuresRating) {
		this.featuresRating = featuresRating;
	}

	public Integer getPerformanceRating() {
		return performanceRating;
	}

	public void setPerformanceRating(Integer performanceRating) {
		this.performanceRating = performanceRating;
	}

	public String getReview() {
		return review;
	}

	public void setReview(String review) {
		this.review = review;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((brand == null) ? 0 : brand.hashCode());
		result = prime * result
				+ ((designRating == null) ? 0 : designRating.hashCode());
		result = prime * result
				+ ((featuresRating == null) ? 0 : featuresRating.hashCode());
		result = prime * result + ((model == null) ? 0 : model.hashCode());
		result = prime
				* result
				+ ((performanceRating == null) ? 0 : performanceRating
						.hashCode());
		result = prime * result + ((review == null) ? 0 : review.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Review other = (Review) obj;
		if (brand == null) {
			if (other.brand != null)
				return false;
		} else if (!brand.equals(other.brand))
			return false;
		if (designRating == null) {
			if (other.designRating != null)
				return false;
		} else if (!designRating.equals(other.designRating))
			return false;
		if (featuresRating == null) {
			if (other.featuresRating != null)
				return false;
		} else if (!featuresRating.equals(other.featuresRating))
			return false;
		if (model == null) {
			if (other.model != null)
				return false;
		} else if (!model.equals(other.model))
			return false;
		if (performanceRating == null) {
			if (other.performanceRating != null)
				return false;
		} else if (!performanceRating.equals(other.performanceRating))
			return false;
		if (review == null) {
			if (other.review != null)
				return false;
		} else if (!review.equals(other.review))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Review [brand=" + brand + ", designRating=" + designRating
				+ ", featuresRating=" + featuresRating + ", model=" + model
				+ ", performanceRating=" + performanceRating + ", review="
				+ review + "]";
	}
}
