package com.hospital.entity;

public class Symptom {
	private int diseaseId;
	private String symptomName;
	private String description;
	 
	public Symptom() {
		// TODO Auto-generated constructor stub
	}
	
	public Symptom(int diseaseId, String symptomName, String description) {
		super();
		this.diseaseId = diseaseId;
		this.symptomName = symptomName;
		this.description = description;
	}

	public int getDiseaseId() {
		return diseaseId;
	}

	public void setDiseaseId(int diseaseId) {
		this.diseaseId = diseaseId;
	}

	public String getSymptomName() {
		return symptomName;
	}

	public void setSymptomName(String symptomName) {
		this.symptomName = symptomName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Symptom(int id, int diseaseId, String symptomName, String description) {
		super();
		this.diseaseId = diseaseId;
		this.symptomName = symptomName;
		this.description = description;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((description == null) ? 0 : description.hashCode());
		result = prime * result + diseaseId;
		result = prime * result
				+ ((symptomName == null) ? 0 : symptomName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Symptom other = (Symptom) obj;
		if (description == null) {
			if (other.description != null)
				return false;
		} else if (!description.equals(other.description))
			return false;
		if (diseaseId != other.diseaseId)
			return false;
		if (symptomName == null) {
			if (other.symptomName != null)
				return false;
		} else if (!symptomName.equals(other.symptomName))
			return false;
		return true;
	}

	public String toString() {
		return "Symptom [description=" + description + ", diseaseId="
				+ diseaseId + ", symptomName=" + symptomName + "]";
	}

	
	

}
