package com.hospital.web;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hospital.dao.HospitalManagementDao;
import com.hospital.dao.HospitalManagementDaoJdbcImpl;
import com.hospital.entity.Disease;
import com.hospital.entity.Symptom;


public class FrontControllerServletHospital extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private static final String ADD_DISEASES="addDiseases.action";
	private static final String ADD_DiSEASES_FORM = "AddDiseaseForm.action";
	private static final String ADD_SYMPTOM_FORM="addSymptomForm.action";
	private static final String ADD_SYMPTOM="addSymptom.action";
	private static final String CHECK_PATIENT_FORM="checkPatientForm.action";
	private static final String CHECK_PATIENT_SEARCH="checkPatientSearch.action";

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url=request.getRequestURI();
		
		if(url.endsWith(ADD_DISEASES)){
			doAddDiseasesAction(request,response);
		}else if(url.endsWith(ADD_DiSEASES_FORM)){
			doAddDiseasesFormAction(request,response);
		}else if(url.endsWith(ADD_SYMPTOM_FORM)){
			doAddSymptomForm(request,response);
		}else if(url.endsWith(ADD_SYMPTOM)){
			doAddSymptom(request,response);
		}else if(url.endsWith(CHECK_PATIENT_FORM)){
			doAddCheckPatientForm(request,response);
		}else if(url.endsWith(CHECK_PATIENT_SEARCH)){
			doCheckPatientSearchAction(request,response);
		}
		else{
			response.sendError(404,"URL Not Found......");
		}
	}

	private void doCheckPatientSearchAction(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String forwardPath="successSearch.jsp";
		try
		{
			String patientName=request.getParameter("patientName");
			String symptomsA[]=request.getParameterValues("symptoms");
			
			HospitalManagementDao dao=new HospitalManagementDaoJdbcImpl();
			List<Disease> resultDiseases=dao.searchDiseases(symptomsA);
			System.out.println(resultDiseases);
			List<String> symp=new ArrayList<String>();
			for(String str : symptomsA){
				symp.add(str);
			}
			
			Date dt=new Date();
			
			request.setAttribute("name", patientName);
			request.setAttribute("diseases", resultDiseases);
			request.setAttribute("selectedSymp", symp);
			request.setAttribute("dateAndTime", dt);
			
		}
		catch (Exception e) {
			forwardPath="error1.jsp";
			e.printStackTrace();
		}
		RequestDispatcher dis=request.getRequestDispatcher(forwardPath);
		dis.forward(request, response);
		
	}

	private void doAddCheckPatientForm(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String forwardPath="checkPatient.jsp";
		try
		{
			HospitalManagementDao dao=new HospitalManagementDaoJdbcImpl();
			List<Symptom> symptoms=dao.getAllSymptoms();
			
			request.setAttribute("symptoms", symptoms);
		}
		catch (Exception e) {
			e.printStackTrace();
			forwardPath="error1.jsp";
		}
		RequestDispatcher dis=request.getRequestDispatcher(forwardPath);
		dis.forward(request, response);
		
	}

	private void doAddSymptom(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		HospitalManagementDao dao=new HospitalManagementDaoJdbcImpl();
		String forwardPath="addSymptomSuccess.jsp";
		
		try{
			Symptom symptom=new Symptom();
			Integer diseaseId=Integer.parseInt(request.getParameter("diseases"));
			String symptomName=request.getParameter("name");
			String description=request.getParameter("desc");
		
			symptom.setDiseaseId(diseaseId);
			symptom.setSymptomName(symptomName);
			symptom.setDescription(description);
			
			dao.addSymptom(symptom);
		}
		catch (Exception e) {
			forwardPath="error1.jsp";
			e.printStackTrace();
		}
		RequestDispatcher dispatcher=request.getRequestDispatcher(forwardPath);
		dispatcher.forward(request, response);
	}

	private void doAddSymptomForm(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException{
		String forwardPath="AddSymptomForm.jsp";
		
		HospitalManagementDao dao=new HospitalManagementDaoJdbcImpl();
		try
		{
			List<Disease> d=dao.getAllDiseases();
			request.setAttribute("diseases",d);
		}
		catch (Exception e) {
			forwardPath="error1.jsp";
			e.printStackTrace();
		}
		RequestDispatcher dispatcher=request.getRequestDispatcher(forwardPath);
		dispatcher.forward(request, response);
	}

	private void doAddDiseasesFormAction(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String forwardPath="AddDisease.jsp";
		RequestDispatcher dis=request.getRequestDispatcher(forwardPath);
		dis.forward(request, response);	
	}

	private void doAddDiseasesAction(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String forwardPath="addedSuccess.jsp";
		try
		{
			Disease d=new Disease();
			
			String diseaseName=request.getParameter("diseaseName");  
			String severity=request.getParameter("severity");
			String causes=request.getParameter("cause");
			String desc=request.getParameter("desc");
			
			d.setName(diseaseName);
			d.setSeverity(severity);
			d.setCause(causes);
			d.setDescription(desc);
			
			HospitalManagementDao dao=new HospitalManagementDaoJdbcImpl();
			dao.addDisease(d);
			
		}catch (Exception e) {
			forwardPath="error1.jsp";
			e.printStackTrace();
		}
		RequestDispatcher rd=request.getRequestDispatcher(forwardPath);
		rd.forward(request, response);
	}
}
