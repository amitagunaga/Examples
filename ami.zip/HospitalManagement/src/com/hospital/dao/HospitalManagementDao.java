package com.hospital.dao;

import java.util.List;

import com.hospital.entity.Disease;
import com.hospital.entity.Symptom;
import com.hospital.exceptions.DaoException;

public interface HospitalManagementDao {
	void addDisease(Disease d) throws DaoException;
	void addSymptom(Symptom s) throws DaoException;
	List<Disease> getAllDiseases() throws DaoException;
	List<Symptom> getAllSymptoms() throws DaoException;
	List<Disease> searchDiseases(String[] symptoms) throws DaoException;
}
