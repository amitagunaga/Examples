package com.hospital.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.hospital.entity.Disease;
import com.hospital.entity.Symptom;
import com.hospital.exceptions.DaoException;

public class HospitalManagementDaoJdbcImpl implements HospitalManagementDao {

	private String driverName="com.mysql.jdbc.Driver";
	private String url="jdbc:mysql://localhost:3306/hospital";
	private String user="root";
	private String pwd="Welcome123";
	
	Connection getConnection() throws DaoException{
		Connection conn=null;
		try {
			Class.forName(driverName);
			conn=DriverManager.getConnection(url, user, pwd);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			throw new DaoException();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DaoException();
		}
		return conn;
	}
	void closeStatement(Statement stmt) throws DaoException{
		if(stmt!=null){
			try {
				stmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
				throw new DaoException();
			}
		}
		
	}
	void closeConnection(Connection conn) throws DaoException{
		if(conn!=null){
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
				throw new DaoException();
			}
		}
	}
	void closeResultSet(ResultSet rs) throws DaoException{
		if(rs!=null){
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
				throw new DaoException();
			}
		}
	}
	
	public void addDisease(Disease d) throws DaoException {
		try
		{
			Connection conn=null;
			PreparedStatement pstmt=null;
			ResultSet rs=null;
			
			String sql="insert into disease(name,severity,cause,discription) values(?,?,?,?)";
			
			System.out.println("Adding");
			conn=getConnection();
			
			pstmt=conn.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
			pstmt.setString(1, d.getName());
			pstmt.setString(2, d.getSeverity());
			pstmt.setString(3, d.getCause());
			pstmt.setString(4, d.getDescription());
			
			pstmt.executeUpdate();
			
			rs=pstmt.getGeneratedKeys();
			if(rs.next()){
				d.setId(rs.getInt(1));
			}
			System.out.println("Added");
			
		}catch (Exception e) {
			e.printStackTrace();
			throw new DaoException();
		}
		
	}
	@Override
	public void addSymptom(Symptom s) throws DaoException {
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		
		String sql="insert into symptom(disease_id,symptom_name,description) values(?,?,?)";
		try
		{
			System.out.println("Adding symptom");
			 conn=getConnection();
			 pstmt=conn.prepareStatement(sql);
			 pstmt.setInt(1, s.getDiseaseId());
			 pstmt.setString(2, s.getSymptomName());
			 pstmt.setString(3, s.getDescription());
			 pstmt.executeUpdate();
			 System.out.println("Added symptom");
			
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new DaoException();
		}
	}
	@Override
	public List<Disease> getAllDiseases() throws DaoException {
		Connection conn=null;
		Statement stmt=null;
		ResultSet rs=null;
		
		String sql="select id,name from disease";
		List<Disease> diseases=new ArrayList<Disease>();
		try
		{
			conn=getConnection();
			stmt=conn.createStatement();
			rs=stmt.executeQuery(sql);
			while(rs.next()){
				Disease d=new Disease();
				d.setId(rs.getInt("id"));
				d.setName(rs.getString("name"));
				diseases.add(d);
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return diseases;
	}
	@Override
	public List<Symptom> getAllSymptoms() throws DaoException {
		Connection conn=null;
		Statement stmt=null;
		ResultSet rs=null;
		
		String sql="select distinct symptom_name from symptom";
		List<Symptom> symptoms=new ArrayList<Symptom>();
		try
		{
			conn=getConnection();
			stmt=conn.createStatement();
			rs=stmt.executeQuery(sql);
			while(rs.next()){
				Symptom s=new Symptom();
				s.setSymptomName(rs.getString("symptom_name"));
				symptoms.add(s);
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return symptoms;
	}
	@Override
	public List<Disease> searchDiseases(String[] symptoms) throws DaoException{
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		
		List<Disease> diseases=new ArrayList<Disease>();
		
		String symp = "";
		for(int i=0;i<symptoms.length;i++){
			symp += "'"+symptoms[i]+"',";
		}

//		select distinct d.name,d.severity,count(d.id) from disease d,symptom s where d.id=s.disease_id and s.symptom_name IN('fever',"chest pain")
//		group by d.id;
		
		System.out.println(symp);

		String newSymp = symp.substring(0, (symp.length()-1));
		System.out.println(newSymp);
		
		String sql="select d.name,d.severity,count(d.id) from disease d,symptom s where d.id=s.disease_id and s.symptom_name IN("+newSymp+") group by d.id";
		System.out.println("Query is :"+sql);
		try
		{
			conn=getConnection();
			pstmt=conn.prepareStatement(sql);
			rs=pstmt.executeQuery();
			
			
			while(rs.next()){
				
				Disease d=new Disease();
				
				String name=rs.getString("name");
				String severity=rs.getString("severity");
				Integer countSymptoms=rs.getInt("count(d.id)");
				if(countSymptoms == symptoms.length&&name!=null){
					d.setName(name);
					d.setSeverity(severity);
					diseases.add(d);
				}
				
			}
			
		}catch (Exception e) {
			throw new DaoException();
		}
		return diseases;
	}
}
