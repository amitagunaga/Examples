package com.mindtree.web;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mindtree.dao.ProjectCreationManagementDao;
import com.mindtree.dao.ProjectCreationManagementJdbcImpl;
import com.mindtree.entity.Employee;
import com.mindtree.entity.IndustryGroup;
import com.mindtree.entity.Project;
import com.mindtree.entity.ProjectResult;
import com.mindtree.entity.SearchObj;
import com.mindtree.entity.Technology;
import com.mindtree.exceptions.ApplicationException;
import com.mindtree.exceptions.DaoException;

public class FrontControllerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private static final String ADD_PROJECT_FORM="getAddProjectForm.action";
	private static final String ADD_PROJECTS="addProjectsToDB.action";
	private static final String ADD_EMPLOYEES_TO_PROJECT_F0RM="getAddEmployeesToProjectForm.action";
	private static final String GET_PROJECTS_FOR_IG="getProjectsForIg.action";
	private static final String ADD_PROJECT_ID_FOR_EMPLOYEE="addEmployeesToProject.action";
	private static final String GET_SEARCH_PROJECT_FORM="getSearchProjectForm.action";
	private static final String SEARCH_PROJECTS="searchProjectsFromTable.action";

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String uri=request.getRequestURI();
		if(uri.endsWith(ADD_PROJECT_FORM)){
			doAddProjectFormAction(request,response);
		}
		else if(uri.endsWith(ADD_PROJECTS)){
			doAddProjectsAction(request,response);
		}
		else if(uri.endsWith(ADD_EMPLOYEES_TO_PROJECT_F0RM)){
			doAddEmployeesToProjectsAction(request,response);
		}
		else if(uri.endsWith(GET_PROJECTS_FOR_IG)){
			doGetProjectsForIgAction(request,response);
		}
		else if(uri.endsWith(ADD_PROJECT_ID_FOR_EMPLOYEE)){
			doAddProjectIdsToEmployeeAction(request,response);
		}
		else if(uri.endsWith(GET_SEARCH_PROJECT_FORM)){
			doGetSearchProjectFormAction(request,response);
		}
		else if(uri.endsWith(SEARCH_PROJECTS)){
			doSearchProjectsAction(request,response);
		}
		else{
			response.sendError(404, "Requested url not found");
		}
	}

	private void doSearchProjectsAction(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String forwardPath="dispProjectsResults.jsp";
		ProjectCreationManagementDao dao=new ProjectCreationManagementJdbcImpl();
		Date sDateU = null;
		Date eDateU = null;
		
		try{
			String title=request.getParameter("title");
			String description=request.getParameter("descriptionWord");
			String sDate=request.getParameter("sDate");
			String eDate=request.getParameter("eDate");
			
			if(sDate.equals("")){
				sDateU=null; 
			}
			if(eDate.equals("")){
				eDateU=null;
			}
			else
			{
				SimpleDateFormat sdf=new SimpleDateFormat("dd-MMM-yyyy");
				sDateU=sdf.parse(sDate);
				eDateU=sdf.parse(eDate);
				//System.out.println(sDate+"     "+eDate);
				if(sDateU.after(eDateU)){
					throw new ApplicationException("End Date cannot be less than start date");
				}
				else{
					
					List<ProjectResult> ps=dao.searchProjects(title,description,sDateU,eDateU);

					request.setAttribute("result", ps);
					
				}
			}
			if(sDateU==null || eDateU==null){
				List<ProjectResult> ps=dao.searchProjects(title, description, sDateU, eDateU);
				request.setAttribute("result", ps);
			}		
		}
		catch (DaoException e) {
			e.printStackTrace();
			request.setAttribute("errorMess",e.getMessage());
			forwardPath="error1.jsp";
		}
		catch (ParseException e) {
			e.printStackTrace();
			request.setAttribute("errorMess", "Invalid Date format");
			forwardPath="error1.jsp";
		}
		catch (ApplicationException e) {
			e.printStackTrace();
			request.setAttribute("errorMess", "End Date cannot be less than start date");
			forwardPath="error1.jsp";
		}
		catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("errorMess", e.getMessage());
			forwardPath="error1.jsp";
		}		
		RequestDispatcher dis=request.getRequestDispatcher(forwardPath);
		dis.forward(request, response);
	}

	private void doGetSearchProjectFormAction(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		ProjectCreationManagementDao dao=new ProjectCreationManagementJdbcImpl();
		String forwardPath="searchProjects.jsp";
		RequestDispatcher dis=request.getRequestDispatcher(forwardPath);
		dis.forward(request, response);
	}

	private void doAddProjectIdsToEmployeeAction(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		ProjectCreationManagementDao dao=new ProjectCreationManagementJdbcImpl();
		String forwardPath="successPage.jsp";
		try{
			String[] employees=request.getParameterValues("employees");
			Integer projectId=Integer.parseInt(request.getParameter("projects"));
						
			dao.addEmployeesToProject(employees,projectId);
			request.setAttribute("empAdded", "Employees successfully added to projects");
		}
		catch (Exception e) {
			e.printStackTrace();
			forwardPath="error1.jsp";
			request.setAttribute("errorMess", e.getMessage());
		}
		RequestDispatcher dis=request.getRequestDispatcher(forwardPath);
		dis.forward(request, response);
	}

	private void doGetProjectsForIgAction(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		ProjectCreationManagementDao dao=new ProjectCreationManagementJdbcImpl();
		Integer igId=Integer.parseInt(request.getParameter("igId"));
		String forwardPath="dispProjects.jsp";
		try{
			List<Project> projects=dao.getProjectsForIgId(igId);
			request.setAttribute("projects", projects);
		}
		catch (Exception e) {
			e.printStackTrace();
			forwardPath="error1.jsp";
		}
		RequestDispatcher dis=request.getRequestDispatcher(forwardPath);
		dis.forward(request, response);
	}

	private void doAddEmployeesToProjectsAction(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		ProjectCreationManagementDao dao=new ProjectCreationManagementJdbcImpl();
		String forwardPath="AddEmployeesToProject.jsp";
		try{
			List<IndustryGroup> igs=dao.getAllIndustryGroups();
			request.setAttribute("igs", igs);
			
			List<Employee> employees=dao.getAllEmployeesNotAssignedToProject();
			request.setAttribute("emp", employees);
		}
		catch (Exception e) {
			e.printStackTrace();
			forwardPath="error1.jsp";
		}
		RequestDispatcher dis=request.getRequestDispatcher(forwardPath);
		dis.forward(request, response);
	}

	private void doAddProjectsAction(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException{
		
		ProjectCreationManagementDao dao=new ProjectCreationManagementJdbcImpl();
		String forwardPath = "successPage.jsp";
		try{
			Project project=new Project();
			project.setProjectTitle(request.getParameter("title"));
			project.setIndustryGroupId(Integer.parseInt(request.getParameter("industryGroup")));
			project.setProjectType(request.getParameter("projectType"));
			project.setTechnologyId(Integer.parseInt(request.getParameter("technology")));

			String startDate=request.getParameter("startDate");          //doubt how to show error mess fr if date format specifies by user is incorrect n if end date s less than start date
			if(!startDate.matches("[0-9]{2}-[a-zA-Z]{3}-[0-9]{4}")){
				throw new ParseException(startDate, 1);
			}
			SimpleDateFormat sdf=new SimpleDateFormat("dd-MMM-yyyy");
			Date sDateU=sdf.parse(startDate);
			//java.sql.Date sDateS=new java.sql.Date(sDateU.getTime());
			project.setStartDate(sDateU);
			
			String endDate=request.getParameter("endDate");
			if(!endDate.matches("[0-9]{2}-[a-zA-Z]{3}-[0-9]{4}")){
				throw new ParseException(startDate, 1);
			}
			Date eDateU=sdf.parse(endDate);
			project.setEndDate(eDateU);
			
			project.setDescription(request.getParameter("description"));
			
			if(sDateU.after(eDateU)){
				request.setAttribute("dateError", "Start date cannot be greater than end date");
				forwardPath="error1.jsp";
			}
			else{
				dao.addProject(project);
				//System.out.println("Adding...");
				request.setAttribute("successMess", "Project Successfully Added");
				//System.out.println("Added...");
			}
		}catch (ParseException e) {
			e.printStackTrace();
			forwardPath="error1.jsp";
			request.setAttribute("errorMess","Date format specified is not correct");
		}
		catch (Exception e) {
			e.printStackTrace();
			forwardPath="error1.jsp";
			request.setAttribute("errorMess",e.getMessage());
		}	
		RequestDispatcher dis=request.getRequestDispatcher(forwardPath);
		dis.forward(request, response);
	}

	private void doAddProjectFormAction(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		ProjectCreationManagementDao dao=new ProjectCreationManagementJdbcImpl();
		String forwardPath="addProjectForm.jsp";
		try
		{
			List<IndustryGroup> igs=dao.getAllIndustryGroups();
			List<Technology> technologies=dao.getAllTechnologies();
			
			request.setAttribute("igs", igs);
			request.setAttribute("tech", technologies);
			
		}
		catch (Exception e) {
			e.printStackTrace();
			//request.setAttribute("errorInAdding", e.getMessage());
			//forwardPath="error.jsp";
		}
		RequestDispatcher rd=request.getRequestDispatcher(forwardPath);
		rd.forward(request, response);
	}
	
}
