package com.mindtree.entity;

public class ProjectResult {
	private String projectTitle;
	private String projectType;
	private String description;
	private String industryGroup;
	private String technology;
	
	public ProjectResult() {
		// TODO Auto-generated constructor stub
	}

	public ProjectResult(String projectTitle, String projectType,
			String description, String industryGroup, String technology) {
		super();
		this.projectTitle = projectTitle;
		this.projectType = projectType;
		this.description = description;
		this.industryGroup = industryGroup;
		this.technology = technology;
	}

	public String getProjectTitle() {
		return projectTitle;
	}

	public void setProjectTitle(String projectTitle) {
		this.projectTitle = projectTitle;
	}

	public String getProjectType() {
		return projectType;
	}

	public void setProjectType(String projectType) {
		this.projectType = projectType;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getIndustryGroup() {
		return industryGroup;
	}

	public void setIndustryGroup(String industryGroup) {
		this.industryGroup = industryGroup;
	}

	public String getTechnology() {
		return technology;
	}

	public void setTechnology(String technology) {
		this.technology = technology;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((description == null) ? 0 : description.hashCode());
		result = prime * result
				+ ((industryGroup == null) ? 0 : industryGroup.hashCode());
		result = prime * result
				+ ((projectTitle == null) ? 0 : projectTitle.hashCode());
		result = prime * result
				+ ((projectType == null) ? 0 : projectType.hashCode());
		result = prime * result
				+ ((technology == null) ? 0 : technology.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProjectResult other = (ProjectResult) obj;
		if (description == null) {
			if (other.description != null)
				return false;
		} else if (!description.equals(other.description))
			return false;
		if (industryGroup == null) {
			if (other.industryGroup != null)
				return false;
		} else if (!industryGroup.equals(other.industryGroup))
			return false;
		if (projectTitle == null) {
			if (other.projectTitle != null)
				return false;
		} else if (!projectTitle.equals(other.projectTitle))
			return false;
		if (projectType == null) {
			if (other.projectType != null)
				return false;
		} else if (!projectType.equals(other.projectType))
			return false;
		if (technology == null) {
			if (other.technology != null)
				return false;
		} else if (!technology.equals(other.technology))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "ProjectResult [description=" + description + ", industryGroup="
				+ industryGroup + ", projectTitle=" + projectTitle
				+ ", projectType=" + projectType + ", technology=" + technology
				+ "]";
	}
}
