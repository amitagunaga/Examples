package com.mindtree.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.mindtree.entity.Employee;
import com.mindtree.entity.IndustryGroup;
import com.mindtree.entity.ProjectResult;
import com.mindtree.entity.SearchObj;
import com.mindtree.entity.Technology;
import com.mindtree.entity.Project;
import com.mindtree.entity.Technology;
import com.mindtree.exceptions.DaoException;

public class ProjectCreationManagementJdbcImpl implements
		ProjectCreationManagementDao {
	
	private String driverName="com.mysql.jdbc.Driver";
	private String url="jdbc:mysql://localhost:3306/project_creation_management";
	private String user="root";
	private String password="Welcome123";
	
	private Connection getConnection() throws DaoException{
		Connection conn=null;
		try {
			Class.forName(driverName);
			conn=DriverManager.getConnection(url, user, password);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			throw new DaoException();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DaoException();
		}
		return conn;
	}
	
	private void closeConnection(Connection conn) throws DaoException{
		if(conn!=null){
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
				throw new DaoException();
			}
		}
	}
	
	private void closeResultSet(ResultSet rs) throws DaoException{
		if(rs!=null){
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
				throw new DaoException();
			}
		}
	}
	
	private void closeStatement(Statement stmt) throws DaoException{
		if(stmt!=null){
			try {
				stmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
				throw new DaoException();
			}
		}
	}
	@Override
	public void addProject(Project project) throws DaoException {
		Connection conn=null;
		ResultSet rs=null;
		PreparedStatement pstmt=null;
		
		String sql="insert into projects(ig_id,project_type,technology_id,start_date,end_date,description,project_title) values(?,?,?,?,?,?,?)";
		try{
			System.out.println("Adding");
			conn=getConnection();
			pstmt=conn.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
			pstmt.setInt(1,project.getIndustryGroupId());
			pstmt.setString(2, project.getProjectType());
			pstmt.setInt(3, project.getTechnologyId());
			pstmt.setDate(4, new java.sql.Date(project.getStartDate().getTime()));
			pstmt.setDate(5, new java.sql.Date(project.getEndDate().getTime()));
			pstmt.setString(6, project.getDescription());
			pstmt.setString(7, project.getProjectTitle());
			
			pstmt.executeUpdate();
			
			rs=pstmt.getGeneratedKeys();
			if(rs.next()){
				project.setProjectId(rs.getInt(1));
			}
			System.out.println("Added successfuly");
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new DaoException("Error while adding project");
		}finally{
			closeConnection(conn);
			closeResultSet(rs);
			closeStatement(pstmt);
		}
	}
	@Override
	public List<IndustryGroup> getAllIndustryGroups() throws DaoException {
		Connection conn=null;
		Statement stmt=null;
		ResultSet rs=null;
		
		String sql="select * from industry_groups";
		List<IndustryGroup> igs=new ArrayList<IndustryGroup>();
		try{
			conn=getConnection();
			stmt=conn.createStatement();
			rs=stmt.executeQuery(sql);
			
			while(rs.next()){
				IndustryGroup ig=new IndustryGroup();
				ig.setId(rs.getInt("id"));
				ig.setName(rs.getString("name"));
				igs.add(ig);
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new DaoException();
		}
		finally{
			closeConnection(conn);
			closeResultSet(rs);
			closeStatement(stmt);
		}
		return igs;
	}

	@Override
	public List<Technology> getAllTechnologies() throws DaoException {
		Connection conn=null;
		Statement stmt=null;
		ResultSet rs=null;
		
		String sql="select * from technologies";
		List<Technology> technologies=new ArrayList<Technology>();
		try{
			conn=getConnection();
			stmt=conn.createStatement();
			rs=stmt.executeQuery(sql);
			
			while(rs.next()){
				Technology technology=new Technology();
				technology.setId(rs.getInt("id"));
				technology.setName(rs.getString("name"));
				technologies.add(technology);
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new DaoException();
		}
		finally{
			closeConnection(conn);
			closeResultSet(rs);
			closeStatement(stmt);
		}
		return technologies;
	}

	@Override
	public List<Employee> getAllEmployeesNotAssignedToProject() throws DaoException {
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		
		String sql="select * from employees where proj_id is null";
		//String sql="select * from employees";
		List<Employee> employees=new ArrayList<Employee>();
		
		try{
			conn=getConnection();
			pstmt=conn.prepareStatement(sql);
			rs=pstmt.executeQuery();
			while(rs.next()){
				Employee emp=new Employee();
				emp.setMid(rs.getString("mid"));
				emp.setName(rs.getString("name"));
				emp.setProjectId(rs.getInt("proj_id"));
				employees.add(emp);
			}
//			for(Employee e : employees){
//				System.out.println(e.getProjectId());
//			}
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new DaoException();
		}
		finally{
			closeConnection(conn);
			closeResultSet(rs);
			closeStatement(pstmt);
		}
		return employees;
	}

	@Override
	public List<Project> getProjectsForIgId(Integer igId) throws DaoException {
		Connection conn=null;
		ResultSet rs=null;
		PreparedStatement pstmt=null;
		
		String sql="select proj_id,project_title from projects where ig_id = ?";
		List<Project> projects=new ArrayList<Project>();
		try{
			conn=getConnection();
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, igId);
			rs=pstmt.executeQuery();
			while(rs.next()){
				Project p=new Project();
				p.setProjectId(rs.getInt("proj_id"));
				p.setProjectTitle(rs.getString("project_title"));
				projects.add(p);
			}
//			for(Project p : projects){
//				System.out.println("Project Name : "+p.getProjectTitle());
//				System.out.println("Project Id : "+p.getProjectId());
//			}
		}
		catch (Exception e) {
			e.printStackTrace();	
		}
		finally{
			closeConnection(conn);
			closeResultSet(rs);
			closeStatement(pstmt);
		}
		return projects;
	}

	@Override
	public void addEmployeesToProject(String[] emps,Integer projectId) throws DaoException {
//		for(int i=0;i<emps.length;i++){
//			System.out.println("Employee : "+emps[i]);	
//		}
//		System.out.println("Project Id : "+projectId);
		
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try{
			Employee emp=new Employee();
			emp.setProjectId(projectId);
			
			conn=getConnection();
			for(int i=0;i<emps.length;i++){
				System.out.println("Updating...");
				String sql="update employees set proj_id = ? where mid = ?";
				pstmt=conn.prepareStatement(sql);
				pstmt.setInt(1, emp.getProjectId());
				pstmt.setString(2, emps[i]);
				pstmt.executeUpdate();
				System.out.println("updated successfuly");
			}
		}catch (Exception e) {
			e.printStackTrace();
			throw new DaoException("Error while adding employees to project...");
		}finally{
			closeConnection(conn);
			closeResultSet(rs);
			closeStatement(pstmt);
		}
	}

	@Override
	public List<ProjectResult> searchProjects(String title,String descWord,Date sDateU,Date eDateU) throws DaoException {
//		String title=obj.getTitle();
//		String descWord=obj.getDescription();
//		Date sDate=obj.getsDate();
//		Date eDate=obj.geteDate();
		
		Connection conn=null;
		ResultSet rs=null;
		PreparedStatement pstmt=null;
		String sql;
		
		List<ProjectResult> projectsResult=new ArrayList<ProjectResult>();
		/*
		 *select p.project_title,p.project_type,p.description,i.name as 'Industry Group',t.name AS 'Technology Name' from 
			projects p,industry_groups i,technologies t where p.project_title like
			 '%AIG%' and p.description like '%project%' and p.start_date between 
			 '2001-02-05' AND '2020-04-09' and t.id=p.technology_id and i.id=p.ig_id;
		 * 		  
		 */
		
//		String sDateS=sDateU.toString();
//		String eDateS=eDateU.toString();
		
		if(title.equals("") && descWord.equals("") && sDateU==null && eDateU==null){
			sql="select p.project_title,p.project_type,p.description,i.name as 'Industry Group',t.name AS 'Technology Name' " +
				"from projects p,industry_groups i,technologies t where t.id=p.technology_id and i.id=p.ig_id";
			conn=getConnection();
			try {
				pstmt=conn.prepareStatement(sql);
				rs=pstmt.executeQuery();
				while(rs.next()){
					ProjectResult project=new ProjectResult();
					project.setProjectTitle(rs.getString(1));
					project.setProjectType(rs.getString(2));
					project.setDescription(rs.getString(3));
					project.setIndustryGroup(rs.getString(4));
					project.setTechnology(rs.getString(5));
					projectsResult.add(project);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		else{
			sql="select p.project_title,p.project_type,p.description,i.name as 'Industry Group',t.name AS 'Technology Name' " +
					"from projects p,industry_groups i,technologies t where p.project_title like '%"+title+"%' and " +
					"p.description like '%"+descWord+"%' and p.start_date between ? AND ? and t.id=p.technology_id and i.id=p.ig_id";
			
			System.out.println(sql);
			try{
				System.out.println("Searching");
				conn=getConnection();
				pstmt=conn.prepareStatement(sql);
				//pstmt.setString(1,title);
				//pstmt.setString(2, descWord);
				pstmt.setDate(1, new java.sql.Date(sDateU.getTime()));
				pstmt.setDate(2, new java.sql.Date(eDateU.getTime()));
				rs=pstmt.executeQuery();
				while(rs.next()){
					ProjectResult project=new ProjectResult();
					project.setProjectTitle(rs.getString(1));
					project.setProjectType(rs.getString(2));
					project.setDescription(rs.getString(3));
					project.setIndustryGroup(rs.getString(4));
					project.setTechnology(rs.getString(5));
					projectsResult.add(project);			
				}
				System.out.println("Searched...");
			}
			catch (Exception e) {
				e.printStackTrace();
				System.out.println(e.getCause());
				throw new DaoException("Error while searching projects..."+e.getMessage());
			}
			finally{
				closeConnection(conn);
				closeResultSet(rs);
				closeStatement(pstmt);
			}
		}
		return projectsResult;
	}
}
