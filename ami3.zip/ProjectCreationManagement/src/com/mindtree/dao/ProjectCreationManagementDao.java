package com.mindtree.dao;

import java.util.Date;
import java.util.List;

import com.mindtree.entity.Employee;
import com.mindtree.entity.IndustryGroup;
import com.mindtree.entity.Project;
import com.mindtree.entity.ProjectResult;
import com.mindtree.entity.SearchObj;
import com.mindtree.entity.Technology;
import com.mindtree.exceptions.DaoException;

public interface ProjectCreationManagementDao {
	public List<IndustryGroup> getAllIndustryGroups() throws DaoException;
	
	public List<Technology> getAllTechnologies() throws DaoException;
	
	public void addProject(Project project) throws DaoException;
	
	public List<Employee> getAllEmployeesNotAssignedToProject() throws DaoException;
	
	public List<Project> getProjectsForIgId(Integer igId) throws DaoException;
	
	public void addEmployeesToProject(String[] emps,Integer projectId) throws DaoException;

	public List<ProjectResult> searchProjects(String title,String descWord,Date sDateU,Date eDateU) throws DaoException;
}
