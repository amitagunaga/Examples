package com.mindtree.web;

import java.io.IOException;
import java.sql.ResultSet;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mindtree.dao.ProjectCreationManagementDao;
import com.mindtree.dao.ProjectCreationManagementJdbcImpl;
import com.mindtree.entity.Employee;
import com.mindtree.entity.IndustryGroup;
import com.mindtree.entity.Project;
import com.mindtree.entity.Technology;
import com.mindtree.exceptions.ApplicationException;
import com.mindtree.exceptions.DaoException;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

public class FrontControllerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private static final String ADD_PROJECT_FORM="getAddProjectForm.action";
	private static final String ADD_PROJECTS="addProjectsToDB.action";

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		process(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		process(request, response);	}

	
	protected void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String uri=request.getRequestURI();
		if(uri.endsWith(ADD_PROJECT_FORM)){
			doAddProjectFormAction(request,response);
		}
		if(uri.endsWith(ADD_PROJECTS)){
			doAddProjectsAction(request,response);
		}
		else{
			response.sendError(404,"Requested url cannot be found");
		}
	}
	private void doAddProjectsAction(HttpServletRequest request,
			HttpServletResponse response) {
		ProjectCreationManagementDao dao=new ProjectCreationManagementJdbcImpl();
		String forwardPath="success.jsp";
		
		try{
			SimpleDateFormat sdf=new SimpleDateFormat("dd-MMM-yyyy");
			Project project=new Project();
			project.setProjectTitle(request.getParameter("title"));
			project.setIndustryGroupId(Integer.parseInt(request.getParameter("industryGroup")));
			project.setProjectType(request.getParameter("projectType"));
			project.setTechnologyId(Integer.parseInt(request.getParameter("technology")));
			String strtDate=request.getParameter("startDate");
			Date strtDateU=sdf.parse(strtDate);
			project.setStartDate(strtDateU);
			String endDate=request.getParameter("endDate");
			Date endDateU=sdf.parse(endDate);
			project.setEndDate(endDateU);
			
			
		}
		catch (Exception e) {
			
		}
	}

	private void doAddProjectFormAction(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		ProjectCreationManagementDao dao=new ProjectCreationManagementJdbcImpl();
		String forwardPath="addProjectForm.jsp";
		try
		{
			List<IndustryGroup> igs=dao.getAllIndustryGroups();
			List<Technology> technologies=dao.getAllTechnologies();
			
			request.setAttribute("igs", igs);
			request.setAttribute("tech", technologies);
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		RequestDispatcher rd=request.getRequestDispatcher(forwardPath);
		rd.forward(request, response);
	}
	
}
