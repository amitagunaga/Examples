package com.mindtree.entity;

import java.io.Serializable;
import java.util.Date;

public class Project implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Integer projectId;
	private String projectTitle;
	private Integer industryGroupId;
	private String projectType;
	private Integer technologyId;
	private Date startDate;
	private Date endDate;
	private String description;
	
	public Project() {
		// TODO Auto-generated constructor stub
	}

	public Project(Integer projectId, Integer industryGroupId,
			String projectType, Integer technologyId, Date startDate,
			Date endDate, String description) {
		super();
		this.projectId = projectId;
		this.industryGroupId = industryGroupId;
		this.projectType = projectType;
		this.technologyId = technologyId;
		this.startDate = startDate;
		this.endDate = endDate;
		this.description = description;
	}

	public Integer getProjectId() {
		return projectId;
	}

	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}

	public String getProjectTitle() {
		return projectTitle;
	}

	public void setProjectTitle(String projectTitle) {
		this.projectTitle = projectTitle;
	}

	public Integer getIndustryGroupId() {
		return industryGroupId;
	}

	public void setIndustryGroupId(Integer industryGroupId) {
		this.industryGroupId = industryGroupId;
	}

	public String getProjectType() {
		return projectType;
	}

	public void setProjectType(String projectType) {
		this.projectType = projectType;
	}

	public Integer getTechnologyId() {
		return technologyId;
	}

	public void setTechnologyId(Integer technologyId) {
		this.technologyId = technologyId;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((description == null) ? 0 : description.hashCode());
		result = prime * result + ((endDate == null) ? 0 : endDate.hashCode());
		result = prime * result
				+ ((industryGroupId == null) ? 0 : industryGroupId.hashCode());
		result = prime * result
				+ ((projectId == null) ? 0 : projectId.hashCode());
		result = prime * result
				+ ((projectType == null) ? 0 : projectType.hashCode());
		result = prime * result
				+ ((startDate == null) ? 0 : startDate.hashCode());
		result = prime * result
				+ ((technologyId == null) ? 0 : technologyId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Project other = (Project) obj;
		if (description == null) {
			if (other.description != null)
				return false;
		} else if (!description.equals(other.description))
			return false;
		if (endDate == null) {
			if (other.endDate != null)
				return false;
		} else if (!endDate.equals(other.endDate))
			return false;
		if (industryGroupId == null) {
			if (other.industryGroupId != null)
				return false;
		} else if (!industryGroupId.equals(other.industryGroupId))
			return false;
		if (projectId == null) {
			if (other.projectId != null)
				return false;
		} else if (!projectId.equals(other.projectId))
			return false;
		if (projectType == null) {
			if (other.projectType != null)
				return false;
		} else if (!projectType.equals(other.projectType))
			return false;
		if (startDate == null) {
			if (other.startDate != null)
				return false;
		} else if (!startDate.equals(other.startDate))
			return false;
		if (technologyId == null) {
			if (other.technologyId != null)
				return false;
		} else if (!technologyId.equals(other.technologyId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Project [description=" + description + ", endDate=" + endDate
				+ ", industryGroupId=" + industryGroupId + ", projectId="
				+ projectId + ", projectTitle=" + projectTitle
				+ ", projectType=" + projectType + ", startDate=" + startDate
				+ ", technologyId=" + technologyId + "]";
	}

	
}
