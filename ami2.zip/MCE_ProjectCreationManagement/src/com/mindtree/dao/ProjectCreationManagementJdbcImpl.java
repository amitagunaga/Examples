package com.mindtree.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.mindtree.entity.Employee;
import com.mindtree.entity.IndustryGroup;
import com.mindtree.entity.Technology;
import com.mindtree.entity.Project;
import com.mindtree.entity.Technology;
import com.mindtree.exceptions.ApplicationException;
import com.mindtree.exceptions.DaoException;

public class ProjectCreationManagementJdbcImpl implements
		ProjectCreationManagementDao {
	
	private String driverName="com.mysql.jdbc.Driver";
	private String url="jdbc:mysql://localhost:3306/project_creation_management";
	private String user="root";
	private String password="Welcome123";
	
	private Connection getConnection() throws ApplicationException{
		Connection conn=null;
		try {
			Class.forName(driverName);
			conn=DriverManager.getConnection(url, user, password);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			throw new ApplicationException("Class cannot be found",e);
		} catch (SQLException e) {
			e.printStackTrace();
			throw new ApplicationException("Problem while connecting",e);
		}
		return conn;
	}
	
	private void closeConnection(Connection conn) throws ApplicationException{
		if(conn!=null){
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
				throw new ApplicationException("Problem in closing connection",e);
			}
		}
	}
	
	private void closeResultSet(ResultSet rs) throws ApplicationException{
		if(rs!=null){
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
				throw new ApplicationException("Problem in closing rs",e);
			}
		}
	}
	
	private void closeStatement(Statement stmt) throws ApplicationException{
		if(stmt!=null){
			try {
				stmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
				throw new ApplicationException("Problem in closing statement",e);
			}
		}
	}

	@Override
	public void addProject(Project project) throws DaoException {
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		
		String sql="insert into project(id,title,ig_id,project_type,technology_id,start_date,end_date,description) values (?,?,?,?,?,?,?,?);";
		try{
		}
		catch (Exception e) {
			
		}
		
	}

	@Override
	public List<IndustryGroup> getAllIndustryGroups() throws ApplicationException {
		Connection conn=null;
		Statement stmt=null;
		ResultSet rs=null;
		
		String sql="select * from industry_groups";
		List<IndustryGroup> igs=new ArrayList<IndustryGroup>();
		try{
			conn=getConnection();
			stmt=conn.createStatement();
			rs=stmt.executeQuery(sql);
			
			while(rs.next()){
				IndustryGroup ig=new IndustryGroup();
				ig.setId(rs.getInt("id"));
				ig.setName(rs.getString("name"));
				igs.add(ig);
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new DaoException();
		}
		finally{
			closeConnection(conn);
			closeResultSet(rs);
			closeStatement(stmt);
		}
		return igs;
	}

	@Override
	public List<Technology> getAllTechnologies() throws ApplicationException {
		Connection conn=null;
		Statement stmt=null;
		ResultSet rs=null;
		
		String sql="select * from technologies";
		List<Technology> technologies=new ArrayList<Technology>();
		try{
			conn=getConnection();
			stmt=conn.createStatement();
			rs=stmt.executeQuery(sql);
			
			while(rs.next()){
				Technology technology=new Technology();
				technology.setId(rs.getInt("id"));
				technology.setName(rs.getString("name"));
				technologies.add(technology);
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new DaoException();
		}
		finally{
			closeConnection(conn);
			closeResultSet(rs);
			closeStatement(stmt);
		}
		return technologies;
	}	
}
