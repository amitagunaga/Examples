package com.mindtree.dao;

import java.util.Date;
import java.util.List;

import com.mindtree.entity.Employee;
import com.mindtree.entity.IndustryGroup;
import com.mindtree.entity.Project;
import com.mindtree.entity.Technology;
import com.mindtree.exceptions.ApplicationException;
import com.mindtree.exceptions.DaoException;

public interface ProjectCreationManagementDao {
	public List<IndustryGroup> getAllIndustryGroups() throws DaoException, ApplicationException;
	
	public List<Technology> getAllTechnologies() throws DaoException, ApplicationException;
	
	public void addProject(Project project) throws DaoException;
	
}
