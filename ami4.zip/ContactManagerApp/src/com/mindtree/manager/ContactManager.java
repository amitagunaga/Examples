package com.mindtree.manager;

import org.hibernate.classic.Session;

import com.mindtree.entity.Contact;
import com.mindtree.util.HibernateUtil;

public class ContactManager extends HibernateUtil {
	public ContactManager() {
		System.out.println("Contact mgr");
	}
	public Contact add(Contact contact) {
		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		session.beginTransaction();
		session.save(contact);
		session.getTransaction().commit();
		return contact;
	}
}
