package com.mindtree.action;

import com.mindtree.manager.ContactManager;
import com.mindtree.entity.Contact;

import com.opensymphony.xwork2.ActionSupport;

public class ContactAction extends ActionSupport {

	private static final long serialVersionUID = 1L;
	private Contact contact;
	private ContactManager contactManager;

	public ContactAction() {
		System.out.println("Action constructor");
		contactManager = new ContactManager();		
	}

	public String execute() {
		System.out.println("execute called");
		return "success";
	}

	public String add() {
		System.out.println(getContact());
		try {
			contactManager.add(getContact());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "success";
	}

	public Contact getContact() {		
		return contact;
	}

	public void setContact(Contact contact) {
		this.contact = contact;
	}

}
