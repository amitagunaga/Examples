package com.mindtree.entity;

import java.io.Serializable;
import java.sql.Date;
 
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="contacts")
public class Contact  implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private Integer id;
	private String name;
	private String emailId;
	private Date birthDate; 
	
	public Contact() {
		System.out.println("Now in Contact constructor!");
	}
	
	@Id
	@GeneratedValue
	@Column(name="id")
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	
	@Column(name="name")
	public String getName() {
		System.out.println("getting name "+name+" object "+this);
		return name;
	}
	public void setName(String name) {
		System.out.println("setting name "+name+" object "+this);
		this.name = name;
	}
	
	@Column(name="email_id")
	public String getEmailId() {
		System.out.println("getting emailId "+emailId+" object "+this);
		return emailId;
	}
	public void setEmailId(String emailId) {
		System.out.println("setting emailId "+emailId+" object "+this);
		this.emailId = emailId;
	}
	
	@Column(name="birth_date")
	public Date getBirthDate() {
		System.out.println("getting bithdate "+birthDate +" object "+this);
		return birthDate;
	}
	public void setBirthDate(Date birthDate) {
		System.out.println("setting date "+birthDate+" object "+this);
		this.birthDate = birthDate;
	}
	@Override
	public String toString() {
		return "Contact [birthDate=" + birthDate + ", emailId=" + emailId
				+ ", id=" + id + ", name=" + name + "]";
	}

}
