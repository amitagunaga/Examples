package com.mindtree.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.mindtree.entity.Phone;
import com.mindtree.entity.Review;
import com.mindtree.exceptions.ApplicationException;
import com.mindtree.exceptions.DaoException;
import com.mysql.jdbc.exceptions.jdbc4.MySQLIntegrityConstraintViolationException;

public class PhoneReviewApplicationDaoJdbcImpl implements
		PhoneReviewApplicationDao {

	private String driverName="com.mysql.jdbc.Driver";
	private String url="jdbc:mysql://localhost:3306/phone_review_application";
	private String username="root";
	private String password="Welcome123";
	
	private Connection getConnection() throws ApplicationException{
		Connection conn=null;
		try {
			Class.forName(driverName);
			conn=DriverManager.getConnection(url, username, password);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			throw new ApplicationException("class not found",e);
		} catch (SQLException e) {
			e.printStackTrace();
			throw new ApplicationException("Error in acquiring cnnection",e);
		}
		return conn;
	}
	
	private void closeConnection(Connection conn) throws ApplicationException{
		if(conn != null){
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
				throw new ApplicationException("Error while closing the connection",e);
			}
		}
	}
	
	private void closeStatement(Statement stmt) throws ApplicationException{
		if(stmt != null){
			try {
				stmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
				throw new ApplicationException("Error while closing the Statement",e);
			}
		}
	}
	private void closeResultSet(ResultSet rs) throws ApplicationException{
		if(rs != null){
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
				throw new ApplicationException("Error while closing the Resultset",e);
			}
		}
	}

	@Override
	public void addPhone(Phone phone) throws ApplicationException,DaoException {
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		
		String sql="insert into phone(model,brand,form_factor,weight,connectivity,price,available_from,description) values(?,?,?,?,?,?,?,?)";
		try
		{
			System.out.println("Adding");
			conn=getConnection();
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, phone.getModel());
			pstmt.setString(2, phone.getBrand());
			pstmt.setString(3, phone.getFormFactor());
			pstmt.setInt(4, phone.getWeight());
			pstmt.setString(5, phone.getConnectivity());
			pstmt.setInt(6, phone.getPrice());
			pstmt.setDate(7, new java.sql.Date(phone.getAvailableFrom().getTime()));
			pstmt.setString(8, phone.getDescription());
			pstmt.executeUpdate();
			System.out.println("added...");
		}
		catch (MySQLIntegrityConstraintViolationException e) {
			e.printStackTrace();
			throw new ApplicationException("Cannot have same model name for a particular brand...",e);
		}
		catch (Exception e) {
			throw new DaoException("Error while adding",e);
		}
		finally{
			closeConnection(conn);
			closeResultSet(rs);
			closeStatement(pstmt);
		}
	}

	@Override
	public List<Phone> getAllModelsForABrand(String brand) throws DaoException {
		Connection conn=null;
		ResultSet rs=null;
		Statement stmt=null;
		
		Date todayU=new Date();
		java.sql.Date today=new java.sql.Date(todayU.getTime());
		
		List<Phone> phones=new ArrayList<Phone>();
		String sql="select model from phone where brand = '"+brand+"' and available_from <= '"+today+"'";
		try{
			conn=getConnection();
			stmt=conn.createStatement();
			rs=stmt.executeQuery(sql);
			System.out.println(sql);
			while(rs.next()){
				Phone phone=new Phone();
				phone.setModel(rs.getString("model"));
				phones.add(phone);
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new DaoException("Error while geeting models",e);
		}
		return phones;
	}

	@Override
	public void addReview(Review review) throws ApplicationException,DaoException {
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		
		String sql="insert into reviews(model,brand,design_rating,features_rating,perfrmance_rating,review) values(?,?,?,?,?,?)";
		try
		{
			System.out.println("Adding reviews");
			conn=getConnection();
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, review.getModel());
			pstmt.setString(2, review.getBrand());
			pstmt.setInt(3, review.getDesignRating());
			pstmt.setInt(4, review.getFeaturesRating());
			pstmt.setInt(5, review.getPerformanceRating());
			pstmt.setString(6, review.getReview());
			pstmt.executeUpdate();
			System.out.println("added reviews...");
		}
		catch (Exception e) {
			throw new DaoException("Error while adding reviews",e);
		}
		finally{
			closeConnection(conn);
			closeResultSet(rs);
			closeStatement(pstmt);
		}
		
	}

	@Override
	public List<Phone> getTopRatedPhones() throws DaoException {
		Connection conn=null;
		Statement stmt=null;
		ResultSet rs=null;
		
		String sql="select model,brand,(avg(design_rating)+avg(features_rating)+avg(perfrmance_rating))/3 as 'Final' " +
				"from reviews group by model order by Final desc";
		List<Phone> topPhone=new ArrayList<Phone>();
		try{
			conn=getConnection();
			stmt=conn.createStatement();
			rs=stmt.executeQuery(sql);
			while(rs.next()){
				Phone phone=new Phone();
				phone.setModel(rs.getString(1));
				phone.setBrand(rs.getString(2));
				phone.setPrice(rs.getInt(3));
				topPhone.add(phone);
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new DaoException("Error while searching top rated phones",e);
		}
		return topPhone;
	}

	@Override
	public List<Review> searchPhones(String brand, Integer weight,
			Integer price, boolean currentlyAvailable) {
		
		return null;
	}

	

	

	
}
