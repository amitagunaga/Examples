package com.mindtree.entity;

import java.io.Serializable;
import java.util.Date;

public class Phone implements Serializable {

	private static final long serialVersionUID = 1L;
	private String model;
	private String brand;
	private String formFactor;
	private Integer weight;
	private String connectivity;
	private Integer price;
	private Date availableFrom;
	private String description;
	
	public Phone() {
	}

	public Phone(String model, String brand, String formFactor, Integer weight,
			String connectivity, Integer price, Date availableFrom,
			String description) {
		super();
		this.model = model;
		this.brand = brand;
		this.formFactor = formFactor;
		this.weight = weight;
		this.connectivity = connectivity;
		this.price = price;
		this.availableFrom = availableFrom;
		this.description = description;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getFormFactor() {
		return formFactor;
	}

	public void setFormFactor(String formFactor) {
		this.formFactor = formFactor;
	}

	public Integer getWeight() {
		return weight;
	}

	public void setWeight(Integer weight) {
		this.weight = weight;
	}

	public String getConnectivity() {
		return connectivity;
	}

	public void setConnectivity(String connectivity) {
		this.connectivity = connectivity;
	}

	public Integer getPrice() {
		return price;
	}

	public void setPrice(Integer price) {
		this.price = price;
	}

	public Date getAvailableFrom() {
		return availableFrom;
	}

	public void setAvailableFrom(Date availableFrom) {
		this.availableFrom = availableFrom;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((availableFrom == null) ? 0 : availableFrom.hashCode());
		result = prime * result + ((brand == null) ? 0 : brand.hashCode());
		result = prime * result
				+ ((connectivity == null) ? 0 : connectivity.hashCode());
		result = prime * result
				+ ((description == null) ? 0 : description.hashCode());
		result = prime * result
				+ ((formFactor == null) ? 0 : formFactor.hashCode());
		result = prime * result + ((model == null) ? 0 : model.hashCode());
		result = prime * result + ((price == null) ? 0 : price.hashCode());
		result = prime * result + ((weight == null) ? 0 : weight.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Phone other = (Phone) obj;
		if (availableFrom == null) {
			if (other.availableFrom != null)
				return false;
		} else if (!availableFrom.equals(other.availableFrom))
			return false;
		if (brand == null) {
			if (other.brand != null)
				return false;
		} else if (!brand.equals(other.brand))
			return false;
		if (connectivity == null) {
			if (other.connectivity != null)
				return false;
		} else if (!connectivity.equals(other.connectivity))
			return false;
		if (description == null) {
			if (other.description != null)
				return false;
		} else if (!description.equals(other.description))
			return false;
		if (formFactor == null) {
			if (other.formFactor != null)
				return false;
		} else if (!formFactor.equals(other.formFactor))
			return false;
		if (model == null) {
			if (other.model != null)
				return false;
		} else if (!model.equals(other.model))
			return false;
		if (price == null) {
			if (other.price != null)
				return false;
		} else if (!price.equals(other.price))
			return false;
		if (weight == null) {
			if (other.weight != null)
				return false;
		} else if (!weight.equals(other.weight))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Phone [availableFrom=" + availableFrom + ", brand=" + brand
				+ ", connectivity=" + connectivity + ", description="
				+ description + ", formFactor=" + formFactor + ", model="
				+ model + ", price=" + price + ", weight=" + weight + "]";
	}
}
