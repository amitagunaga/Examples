function fnValidateVehicle(frm) {
	var msg="";
	var valid=true;
	alert("hi");
	alert("inside fnValidateVehicle");
	if(frm.regNo.value == ""){
		msg+="<br /> Registration no is required";
		valid=false;
	}
	if(frm.category.value=="0"){
		msg+="<br /> category is required";
			valid=false;
	}
	if(frm.manufacturer.value==""){
		msg+="<br /> manufacturer is required";
			valid=false;
	}
	if(frm.rent.value==""){
		msg+="<br /> rent is required";
			valid=false;
	}
	if(frm.fuel[0].checked==false && frm.fuel[1].checked==false){
		msg+="<br /> Fuel is required";
			valid=false;
	}
	if(frm.mileage.value==""){
		msg+="<br /> mileage is required";
			valid=false;
	}
	if(isNaN(frm.rent.value)){
		msg+="<br /> rent should be numerical";
			valid=false;
	}
	if(isNaN(frm.mileage.value)){
		msg+="<br /> mileage should be numerical";
			valid=false;
	}
	if(!valid){
		document.getElementById("eerDiv").innerHTML=msg;
	}
	return valid;
}