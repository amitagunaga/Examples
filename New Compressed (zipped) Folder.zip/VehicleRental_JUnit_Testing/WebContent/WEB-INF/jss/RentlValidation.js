function fnValidateRental(frm) {
	var msg="";
	var valid=true;

	if(frm.customerName.value == ""){
		msg+="<br /> Customer Name no is required";
		valid=false;
	}
	if(frm.category.value==""){
		msg+="<br /> category is required";
			valid=false;
	}
	if(frm.vehicle.regNo.value==""){
		msg+="<br /> manufacturer is required";
			valid=false;
	}
	if(frm.fromDate.value==""){
		msg+="<br /> rent is required";
			valid=false;
	}
	if(frm.toDate.value==""){
		msg+="<br /> mileage is required";
			valid=false;
	}
	if(!valid){
		document.getElementById("eerDiv").innerHTML=msg;
	}
	return valid;
}