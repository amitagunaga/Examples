package com.mindtree.JUnit;

import static org.junit.Assert.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.hibernate.SessionFactory;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.test.AbstractTransactionalDataSourceSpringContextTests;


import com.mindtree.dao.VehicleRentalDao;
import com.mindtree.entity.DeleteObject;
import com.mindtree.entity.Rental;
import com.mindtree.entity.Vehicle;
import com.mindtree.exceptions.DaoException;

public class DaoTest extends AbstractTransactionalDataSourceSpringContextTests  {

	public Vehicle v=new Vehicle();

	public SessionFactory sessionFactory = null;
	public DaoTest() {
	}
	
//	@BeforeClass
//	public void initializeVehicle(){
//		System.out.println("-----------initialized vehicle--------");
		 //v=new Vehicle();
	//}
	
	
	protected String[] getConfigLocations() 
	{     
		System.out.println("--------getting the config properties-----");
		return new String[]{"test-spring-config.xml"};
		
		
	}  

	public VehicleRentalDao dao;

	public void setDao(VehicleRentalDao dao) {
		 
		this.dao = dao;
		System.out.println("-----setting the dao-----");
	}

	//	public void setDao(VehicleRentalDao dao) {
//		System.out.println("-----setting the dao-----");
//		this.dao =dao;
//		
//	}    
	public void setSessionFactory(SessionFactory sessionFactory)
	{  
		this.sessionFactory = sessionFactory;
		System.out.println("-----setting the sessionfactory-----");
		
	}
	
	@Test(expected=Exception.class)
	public void testAddVehicle() throws Exception {
			dao.addVehicle(new Vehicle("KA-2020-10","Car","TATA",200,15,"petrol","Good Company"));	
	}

	@Test(expected=Exception.class)
	public void testBookVehicle() throws Exception {
			SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
			Date fromDateU=sdf.parse("01-12-2011");
			Date toDateU=sdf.parse("15-12-2011");
			Rental r=new Rental("Abhi","Truck",fromDateU,toDateU,v);
			r.getVehicle().setRegNo("KA-2020-04");
			//dao.bookVehicle(new Rental("Amita","Truck",new java.util.Date(2010,9,12),new java.util.Date(2010,9,15),v));
			dao.bookVehicle(r);
	}

	@Test(expected=Exception.class)
	public void testDeleteRentalObject() throws Exception {
			SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
			Date from=sdf.parse("12-9-2011");
			Date to=sdf.parse("13-9-2011");
			DeleteObject deleteObject=new DeleteObject("KA-2011-12",from,to);
			System.out.println(deleteObject);
			dao.deleteRentalObject(deleteObject);	
	}
	
	@AfterClass
	public void releaseResources(){
		dao=null;
		sessionFactory=null;
		System.out.println("-----releasing-----");
	}

}
