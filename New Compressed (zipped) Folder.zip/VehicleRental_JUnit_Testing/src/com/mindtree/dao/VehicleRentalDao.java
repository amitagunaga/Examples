package com.mindtree.dao;

import java.util.List;

import com.mindtree.entity.DeleteObject;
import com.mindtree.entity.Rental;
import com.mindtree.entity.Vehicle;
import com.mindtree.exceptions.DaoException;

public interface VehicleRentalDao {
	public void addVehicle(Vehicle vehicle) throws DaoException;
	public void bookVehicle(Rental rental) throws DaoException;
	public List<Vehicle> getVehiclesForACategory(String category) throws DaoException;
	public void  deleteRentalObject(DeleteObject deleteObject) throws DaoException;
}
