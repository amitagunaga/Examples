package com.mindtree.dao;

//import javax.swing.plaf.basic.BasicScrollPaneUI.HSBChangeListener;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.orm.hibernate3.HibernateTemplate;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.mindtree.entity.DeleteObject;
import com.mindtree.entity.Rental;
import com.mindtree.entity.Vehicle;
import com.mindtree.exceptions.DaoException;

public class VehicleRentalDaoHibernateImpl extends HibernateDaoSupport  implements VehicleRentalDao  {

//	@Autowired
//	HibernateTemplate template;
//	
//	public HibernateTemplate getTemplate() {
//		return template;
//	}

//	public void setTemplate(HibernateTemplate template) {
//		this.template = template;
//	}

	@Override
	public void addVehicle(Vehicle vehicle){
		System.out.println(vehicle);
		try{
			System.out.println("the saved id returned==  "+getHibernateTemplate().save(vehicle));
			System.out.println("hiiiiiiiiiiiiiiiiiiiiiiiiiiiiii");
			System.out.println("The vehicle has been successfully added....");
		}
		catch (Exception e) {
			e.printStackTrace();
			System.out.println("there was some internal problem  or incomplete data");
		}
	}

	@Override
	public void bookVehicle(Rental rental){
		try {
			System.out.println(rental);
			System.out.println("reg No : "+rental.getVehicle().getRegNo());
			
			java.sql.Date from=new java.sql.Date(rental.getFromDate().getTime());
			java.sql.Date to=new java.sql.Date(rental.getToDate().getTime());
			
			Session session=getHibernateTemplate().getSessionFactory().openSession();
			Query qry=session.createSQLQuery("insert into rental(cust_name,reg_no,category,from_date,to_date) values(?,?,?,?,?)");
			qry.setString(0, rental.getCustomerName());
			qry.setString(1, rental.getVehicle().getRegNo());
			qry.setString(2, rental.getCategory());
			qry.setDate(3, from);
			qry.setDate(4, to);
			int count=qry.executeUpdate();
			if(count==0){
				throw new HibernateException("Entered data does not exists to cancel");
			}
			System.out.println("success!! count is : "+count);
			System.out.println("The vehicle has been successfully booked....");
			//		System.out.println("The Saved id for Rental : "+getHibernateTemplate().save(rental));
			
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Problem in booking vehicle..Due to internal errors or data given is incorrect...");
			
		}
	}

	@Override
	public List<Vehicle> getVehiclesForACategory(String category)
			throws DaoException {
		return(getHibernateTemplate().find("from Vehicle where category = ?",category));
	}

	@Override
	public void deleteRentalObject(DeleteObject deleteObject)
	{
		
		java.sql.Date from=new java.sql.Date(deleteObject.getFromDate().getTime());
		java.sql.Date to=new java.sql.Date(deleteObject.getToDate().getTime());
		System.out.println("reg No : "+deleteObject.getRegistrationNumber());
		System.out.println("from "+from);
		System.out.println("from "+to);
		try {
			Session session=getHibernateTemplate().getSessionFactory().openSession();
			Query qry=session.createSQLQuery("delete from rental where reg_no='"+deleteObject.getRegistrationNumber()+"' and from_date='"+from+"' and to_date='"+to+"'");
			int count=qry.executeUpdate();
			if(count==0){
				throw new HibernateException("Entered data does not exists to cancel");
			}
			System.out.println("The Rental has been successfully cancelled....");
			//System.out.println("No of rows affected: 565656 $$$$$$$$$$"+qry.executeUpdate());
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Problem in canceling the rental..Due to internal errors or data given is incorrect..");
			
		}
		 
	}
}
