package com.mindtree.entity;

import java.io.Serializable;
import java.util.Date;

public class Rental implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private Integer rentalId;
	private String customerName;
	private String category;
	private Date fromDate;
	private Date toDate;
	
	public Rental(String customerName, String category, Date fromDate,
			Date toDate) {
		super();
		this.customerName = customerName;
		this.category = category;
		this.fromDate = fromDate;
		this.toDate = toDate;
		
	}
	
	private Vehicle vehicle;   //many to one mapping  
	
	public Rental() {
		vehicle=new Vehicle();
	}
	
	public Rental(String customerName, String category, Date fromDate,
			Date toDate, Vehicle vehicle) {
		super();
		this.customerName = customerName;
		this.category = category;
		this.fromDate = fromDate;
		this.toDate = toDate;
		this.vehicle = vehicle;
	}

	public Vehicle getVehicle() {
		return vehicle;
	}

	public void setVehicle(Vehicle vehicle) {
		this.vehicle = vehicle;
	}

	

	public Integer getRentalId() {
		return rentalId;
	}

	public void setRentalId(Integer rentalId) {
		this.rentalId = rentalId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public Date getFromDate() {
		return fromDate;
	}

	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	public Date getToDate() {
		return toDate;
	}

	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}

	

	public Rental(Integer rentalId, String customerName, String category,
			Date fromDate, Date toDate, Vehicle vehicle) {
		super();
		this.rentalId = rentalId;
		this.customerName = customerName;
		this.category = category;
		this.fromDate = fromDate;
		this.toDate = toDate;
		this.vehicle = vehicle;
	}

	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((category == null) ? 0 : category.hashCode());
		result = prime * result
				+ ((customerName == null) ? 0 : customerName.hashCode());
		result = prime * result
				+ ((fromDate == null) ? 0 : fromDate.hashCode());
		result = prime * result
				+ ((rentalId == null) ? 0 : rentalId.hashCode());
		result = prime * result + ((toDate == null) ? 0 : toDate.hashCode());
		result = prime * result + ((vehicle == null) ? 0 : vehicle.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Rental other = (Rental) obj;
		if (category == null) {
			if (other.category != null)
				return false;
		} else if (!category.equals(other.category))
			return false;
		if (customerName == null) {
			if (other.customerName != null)
				return false;
		} else if (!customerName.equals(other.customerName))
			return false;
		if (fromDate == null) {
			if (other.fromDate != null)
				return false;
		} else if (!fromDate.equals(other.fromDate))
			return false;
		if (rentalId == null) {
			if (other.rentalId != null)
				return false;
		} else if (!rentalId.equals(other.rentalId))
			return false;
		if (toDate == null) {
			if (other.toDate != null)
				return false;
		} else if (!toDate.equals(other.toDate))
			return false;
		if (vehicle == null) {
			if (other.vehicle != null)
				return false;
		} else if (!vehicle.equals(other.vehicle))
			return false;
		return true;
	}
	@Override
	public String toString(){
		return (" "+customerName+" "+category+" "+fromDate+" "+toDate);	
	}

	
}
