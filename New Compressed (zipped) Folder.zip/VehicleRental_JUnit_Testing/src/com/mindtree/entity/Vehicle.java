package com.mindtree.entity;

import java.io.Serializable;

public class Vehicle implements Serializable {
	
	private static final long serialVersionUID = 1L;
	//private Integer vehicleId;
	private String regNo;
	private String category;
	private String manufacturer;
	private Integer rent;
	private Integer mileage;
	private String fuel;
	private String description;

	public Vehicle() {

	}

//	public Integer getVehicleId() {
//		return vehicleId;
//	}
//
//	public void setVehicleId(Integer vehicleId) {
//		this.vehicleId = vehicleId;
//	}

	public String getRegNo() {
		return regNo;
	}

	public void setRegNo(String regNo) {
		this.regNo = regNo;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getManufacturer() {
		return manufacturer;
	}

	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}

	public Integer getRent() {
		return rent;
	}

	public void setRent(Integer rent) {
		this.rent = rent;
	}

	public Integer getMileage() {
		return mileage;
	}

	public void setMileage(Integer mileage) {
		this.mileage = mileage;
	}

	public String getFuel() {
		return fuel;
	}

	public void setFuel(String fuel) {
		this.fuel = fuel;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Vehicle(String regNo, String category,
			String manufacturer, Integer rent, Integer mileage, String fuel,
			String description) {
		super();
		this.regNo = regNo;
		this.category = category;
		this.manufacturer = manufacturer;
		this.rent = rent;
		this.mileage = mileage;
		this.fuel = fuel;
		this.description = description;
	}

	
	@Override
	public String toString() {
		return (regNo+" "+category+" "+manufacturer+" "+rent+" "+mileage+" "+fuel+" "+description+" ");
	}




}
