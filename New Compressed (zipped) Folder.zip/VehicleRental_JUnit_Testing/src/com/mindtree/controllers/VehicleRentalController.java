package com.mindtree.controllers;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;


import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.mindtree.dao.VehicleRentalDao;
import com.mindtree.entity.DeleteObject;
import com.mindtree.entity.Rental;
import com.mindtree.entity.Vehicle;
import com.mindtree.exceptions.DaoException;
import com.mindtree.validators.BookingDetailsValidator;
import com.mindtree.validators.VehicleValidator;

@Controller
public class VehicleRentalController {
	@Autowired
	VehicleRentalDao dao;
	SessionFactory sessionFactory;
	
	

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	

	@InitBinder
	public void myCustomDateBinder(WebDataBinder binder){
		SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
		binder.registerCustomEditor(Date.class, new CustomDateEditor(sdf, true));
	}
	
	@RequestMapping(value="/addVehicleForm.action")
	public String getAddVehicleForm(Model model){
		Vehicle vehicle=new Vehicle();
		model.addAttribute("vehicle", vehicle);
		return "addVehicleForm";
	}
	
	@RequestMapping(value="/addVehicle.action")
	public String addVehicleToDb(Model model,@ModelAttribute("vehicle") Vehicle vehicle,BindingResult errorResults){
		
		org.springframework.validation.Validator validator=new VehicleValidator();
		validator.validate(vehicle, errorResults);
		if(errorResults.hasErrors()){
			return "addVehicleForm";
		}
		else{
			try {
				dao.addVehicle(vehicle);
				model.addAttribute("msg", "Successfully Added");
			} catch (Exception e) {
				e.printStackTrace();
				model.addAttribute("Errormsg", e.getMessage());
			}
		}
		return "successPage";
	}
	
	@RequestMapping(value="/bookVehicleForm.action")
	public String bookVehicleForm(Model model){
		Rental rental =new Rental();
		model.addAttribute("rental", rental);
		return "bookVehicleForm";
	}
	
	@RequestMapping(value="/bookVehicle.action")
	public String bookVehicle(Model model,@ModelAttribute("rental") Rental rental,BindingResult errorResults){
		org.springframework.validation.Validator validator=new BookingDetailsValidator();
		validator.validate(rental, errorResults);
		if(errorResults.hasErrors()){
			return "bookVehicleForm";
		}
		try {
			dao.bookVehicle(rental);
			model.addAttribute("msg", "successfully booked");
		} catch (Exception e) {
			model.addAttribute("Errormsg", e.getMessage());
			return "bookVehicleForm";
		}
		return "successPage";
	}
	
	@RequestMapping(value="/getRegNumberForACategory.action",method=RequestMethod.GET)
	public String getRegistrationNumberForACategory(@RequestParam("category") String category,Model model){
		List<Vehicle> vehicles = null;
		try {
			vehicles=dao.getVehiclesForACategory(category);
			model.addAttribute("vehicles", vehicles);
			for(Vehicle v : vehicles){
				System.out.println("Id "+v.getRegNo());
			System.out.println();
			}
		} catch (DaoException e) {
			e.printStackTrace();
			model.addAttribute("error", e.getMessage());
			model.addAttribute("vehicles", vehicles);
			return "bookVehicleForm";
		}
		return "registrationNumDisp";
	}
	
	@RequestMapping(value="/deleteBooking.action")
	public String deleteObject(@ModelAttribute("deleteObject") DeleteObject deleteObject,Model model){
		try {
			dao.deleteRentalObject(deleteObject);
			//System.out.println("got the rental obj's");
			model.addAttribute("msg", "Successfully deleted");
		} catch (Exception e) {
			e.printStackTrace();
			model.addAttribute("Errormsg", e.getMessage());
		}
		return "successPage";
	}
	
	private void printRental(List<Rental> rentalObject) {
		Iterator<Rental> iter=rentalObject.iterator();
		System.out.println("8748574857 printing");
		while(iter.hasNext()){
			System.out.println(iter.next().getCustomerName());
		}
	}

	@RequestMapping(value="/deleteObjectForm.action")
	public String getDeleteObjectForm(Model model){
		DeleteObject obj=new DeleteObject();
		model.addAttribute("deleteObject", obj);
		return "DeleteVehicleForm";
	}
}


















