package com.mindtree.validators;

import java.util.Date;

import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.mindtree.entity.Rental;

public class BookingDetailsValidator implements Validator {

	@Override
	public boolean supports(Class clazz) {
		return clazz.isAssignableFrom(Rental.class);
	}

	@Override
	public void validate(Object obj, Errors errors) {
		//BookingDetails bookingDetails=(BookingDetails) obj;
		Rental bookingDetails=(Rental) obj;
		
		String custName=bookingDetails.getCustomerName();
		String vehiclCat=bookingDetails.getCategory();
		String vehicleRegNoReferingVehicleId=bookingDetails.getVehicle().getRegNo();
		Date bookedFromDate=bookingDetails.getFromDate();
		Date bookedToDate=bookingDetails.getToDate();
		
		if(custName == null || custName.trim().length()==0){
			errors.rejectValue("customerName", "", "Please Enter Customer Name");
		}
		if(vehiclCat.equals("0")){
			errors.rejectValue("category", "", "Please Category Name of the vehicle you want to book");
		}
		if(vehicleRegNoReferingVehicleId.equals("0")){
			errors.rejectValue("vehicle.regNo", "", "Please Enter Registration Number of the vehicle you want to book");
		}
		if(bookedFromDate == null){
			errors.rejectValue("fromDate", "", "Please Enter From date of the vehicle you want to book");
		}
		if(bookedToDate == null){
			errors.rejectValue("toDate", "", "Please Enter to date of the vehicle you want to book");
		}
		if(bookedFromDate != null && bookedToDate!=null){
			if(bookedFromDate.after(bookedToDate)){
				errors.rejectValue("toDate", "", "To date cannot be prior to  from date");
			}
		}
	}

}
