package com.mindtree.validators;

import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.mindtree.entity.Vehicle;

public class VehicleValidator implements Validator {

	@Override
	public boolean supports(Class clazz) {
		return clazz.isAssignableFrom(Vehicle.class);
	}

	@Override
	public void validate(Object obj, Errors errors) {
		Vehicle vehicle=(Vehicle) obj;

		String regNumber=vehicle.getRegNo();
		String vehicleCat=vehicle.getCategory();
		String manufacturer=vehicle.getManufacturer();
		Integer dailyRent=vehicle.getRent();
		Integer milage=vehicle.getMileage();
		String fuelType=vehicle.getFuel();
	//	String desc=vehicle.getDescription();
		
		if(regNumber == null || regNumber.trim().length()==0){
			errors.rejectValue("regNo", "", "Please enter registration Number");
		}
		if(vehicleCat.equals("0")){
			errors.rejectValue("category", "", "Please enter vehicleCategory");
		}
		
		if(manufacturer == null || manufacturer.trim().length()==0){
			errors.rejectValue("manufacturer", "", "Please enter manufacturer");
		}
		if(dailyRent == null){
			errors.rejectValue("rent", "", "Please enter dailyRent");
			}
//			else if(dailyRent.toString().matches("[a-zA-Z]{*}")){
//				System.out.println("hi");
//				errors.rejectValue("rent", "", "It must be numeric");
//			}
		if(milage == null){
			errors.rejectValue("mileage", "", "Please enter milage");
		}
		if(fuelType == null || fuelType.trim().length()==0){
			errors.rejectValue("fuel", "", "Please enter fuelType");
		}
	}

}
