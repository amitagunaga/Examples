/**
 * 
 */
package com.mindtree.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mindtree.entity.Category;
import com.mindtree.entity.Vehicle;
import com.mindtree.exceptions.DaoException;

/**
 * @author M1016454
 * 
 */
public class VehicleRentalDaoJdbcImpl implements VehicleRentalDao {

	public Connection getConnection() throws DaoException {
		try {
			String driver = "com.mysql.jdbc.Driver";
			String url = "jdbc:mysql://localhost:3306/vehicle_rental";
			String user = "root";
			String password = "Welcome123";

			Class.forName(driver);
			Connection conn = DriverManager.getConnection(url, user, password);

			return conn;
		} catch (Exception e) {
			throw new DaoException(e);
		}
	}

	public List<Category> getCategories() throws DaoException {

		try {
			Connection conn = getConnection();

			List<Category> categoryList = new ArrayList<Category>();

			String sql = "select category_id,category_name from categories";
			Statement stmt = null;
			ResultSet rs = null;
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			while (rs.next()) {
				Category c = new Category();
				c.setCategoryId(rs.getInt("category_id"));
				c.setCategoryName(rs.getString("category_name"));
				categoryList.add(c);
			}
			return categoryList;

		} catch (Exception e) {
			throw new DaoException(e);
		}
	}

	public List<Vehicle> getRegistrationNumbers(Integer cat)
			throws DaoException {

		try {
			Connection conn = getConnection();
			List<Vehicle> registrationNumbersList = new ArrayList<Vehicle>();

			String sql = "select registration_no, fuel_type, mileage, category, daily_rent from vehicles where category='"
					+ cat + "'";
			Statement stmt = null;
			ResultSet rs = null;
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			while (rs.next()) {
				Vehicle v = new Vehicle();
				v.setRegistrationNumber(rs.getString(1));
				v.setFuelType(rs.getString(2));
				v.setMileage(rs.getDouble(3));
				v.setCategory(rs.getString(4));
				v.setDailyRent(rs.getDouble(5));
				registrationNumbersList.add(v);
			}
			return registrationNumbersList;

		} catch (Exception e) {
			throw new DaoException(e);
		}

	}

	public double getDailyRent(String regNum) throws DaoException {
		// TODO Auto-generated method stub
		VehicleRentalDao dao = null;
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		double dailyRent=0.0;
		try {
			dao = new VehicleRentalDaoJdbcImpl();
			conn = getConnection();
			String sql = "select daily_rent from vehicles where registration_no = '"+regNum+"'";
			System.out.println(sql);
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			if (rs.next()) {
				dailyRent = rs.getDouble("daily_rent");
			}
			return dailyRent;

		} catch (Exception e) {
			throw new DaoException(e);
		}
	}

}
