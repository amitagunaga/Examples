/**
 * 
 */
package com.mindtree.dao;

import java.util.List;

import com.mindtree.entity.Category;
import com.mindtree.entity.Vehicle;
import com.mindtree.exceptions.DaoException;

/**
 * @author M1016454
 * 
 */
public interface VehicleRentalDao {

	List<Category> getCategories() throws DaoException;

	public List<Vehicle> getRegistrationNumbers(Integer cat)
			throws DaoException;

	double getDailyRent(String regNum) throws DaoException;

}
