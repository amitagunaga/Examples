/**
 * 
 */
package com.mindtree.exceptions;

/**
 * @author M1016454
 *
 */
public class DaoException extends Exception {

		public DaoException() {
			// TODO Auto-generated constructor stub
		}

		public DaoException(String str, Throwable thr) {
			super(str, thr);
			// TODO Auto-generated constructor stub
		}

		public DaoException(String str) {
			super(str);
			// TODO Auto-generated constructor stub
		}

		public DaoException(Throwable thr) {
			super(thr);
			// TODO Auto-generated constructor stub
		}
		
		

}
