/**
 * 
 */
package com.mindtree.entity;

/**
 * @author M1016454
 * 
 */
public class Vehicle {
	private String registrationNumber;
	private String fuelType;
	private double mileage;
	private String category;
	private double dailyRent;

	public Vehicle() {
		// TODO Auto-generated constructor stub
	}

	public String getRegistrationNumber() {
		return registrationNumber;
	}

	public void setRegistrationNumber(String registrationNumber) {
		this.registrationNumber = registrationNumber;
	}

	public String getFuelType() {
		return fuelType;
	}

	public void setFuelType(String fuelType) {
		this.fuelType = fuelType;
	}

	public double getMileage() {
		return mileage;
	}

	public void setMileage(double mileage) {
		this.mileage = mileage;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public double getDailyRent() {
		return dailyRent;
	}

	public void setDailyRent(double dailyRent) {
		this.dailyRent = dailyRent;
	}

}
