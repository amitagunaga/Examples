package com.mindtree.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mindtree.dao.VehicleRentalDao;
import com.mindtree.dao.VehicleRentalDaoJdbcImpl;
import com.mindtree.entity.Category;
import com.mindtree.entity.Vehicle;
import com.mindtree.exceptions.DaoException;

/**
 * Servlet implementation class VehicleRentServlet
 */
public class VehicleRentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private final static String GET_CATEGORIES = "getCategories.action";
	private final static String GET_NUMBERS = "getRegNumbers.action";
	private final static String GET_RENT = "getTotalRent.action";
	private final static String STORE_DATA = "saveToDatabase.action";
	

	protected void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		try {
		String URI = request.getRequestURI();
		System.out.println("URI : " + URI);
		if (URI.endsWith(GET_CATEGORIES)) {
			getCategoriesAction(request, response);
		} else if (URI.endsWith(GET_NUMBERS)) {
			getRegistrationNumbersAction(request, response);
		} else if (URI.endsWith(GET_RENT)) {
			getTotalRentAction(request, response);
		} else if (URI.endsWith(STORE_DATA)) {
			saveToDatabaseAction(request,response);
		}
		else {
			response.sendError(404, "The requested URI is invalid");
		}
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	private void saveToDatabaseAction(HttpServletRequest request,
			HttpServletResponse response) {
		// TODO Auto-generated method stub
		
	}

	private void getCategoriesAction(final HttpServletRequest request,
			final HttpServletResponse response) throws IOException,
			ServletException {
		System.out.println("Inside function getCategoriesAction");
		VehicleRentalDao dao = new VehicleRentalDaoJdbcImpl();
		String forwardPath = "inputPage.jsp";

		try {
			List<Category> categories = dao.getCategories();
			request.setAttribute("categories", categories);
			System.out.println("category is set");
		} catch (DaoException e) {
			forwardPath = "failure.jsp";
			e.printStackTrace();
		}
		request.getRequestDispatcher(forwardPath).forward(request, response);
		System.out.println("Leaving getCategories function");
	}

	private void getRegistrationNumbersAction(HttpServletRequest request,
			HttpServletResponse response) throws IOException, ServletException {

		System.out.println("entered getRegistrationNumbersAction");

		VehicleRentalDao dao = new VehicleRentalDaoJdbcImpl();
		String forwardPath = "successPage.jsp";

		try {
			System.out.println(request.getParameter("catId"));
			Integer cat = Integer.parseInt(request.getParameter("catId"));
			PrintWriter out = response.getWriter();
			// String uri = request.getRequestURI();
			List<Vehicle> regNumbers = dao.getRegistrationNumbers(cat);
			// request.setAttribute("numbers", regNumbers);
			out
					.print("<select name=\"reg\"><option value=\"\">Select one</option>");
			if (regNumbers != null) {
				for (Vehicle v : regNumbers) {
					System.out.println("printing option");
					out.print("<option value=\"" + v.getRegistrationNumber()
							+ "\">" + v.getRegistrationNumber() + "</option>");
				}
			} else {
				System.out
						.println("registration numbers not retrieved from database");
			}
			out.print("</select>");
			System.out.println("leaving getRegistrationNumbersAction");

		} catch (DaoException e) {
			forwardPath = "failure.jsp";
			e.printStackTrace();

		}

	}

	private void getTotalRentAction(HttpServletRequest request,
			HttpServletResponse response) throws IOException, ServletException,
			DaoException, ParseException {
		
		System.out.println("entered getTotalRentAction");
		VehicleRentalDao dao;
		try {
			PrintWriter out = response.getWriter();
			dao = new VehicleRentalDaoJdbcImpl();
			String date1 = request.getParameter("date1");
			String date2 = request.getParameter("date2");
			
			String regNum = request.getParameter("regNum");
			
			
			SimpleDateFormat sdf = new SimpleDateFormat("dd-mm-yyyy");
			Date startDate = sdf.parse(date1);
			Date endDate = sdf.parse(date2);
			int noOfDays = endDate.getDate() - startDate.getDate();
			double dailyRent = dao.getDailyRent(regNum);
			System.out.println("days:"+noOfDays);
			System.out.println("daily: "+dailyRent);
			double totalRent = dailyRent * noOfDays;
			response.getWriter().print (totalRent);
			
			System.out.println("leaving getTotalRentAction");

		} catch (DaoException e) {
			e.printStackTrace();
		}
	}
}
