package com.paypal.dao;

import com.paypal.exception.ApplicationException;
import com.paypal.exception.DaoException;
import com.paypal.model.Restaurant;

public interface ZomatoDao {

	void addARestaurant(Restaurant restaurant) throws ApplicationException, DaoException;
	
}
