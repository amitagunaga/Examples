package com.paypal.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.paypal.exception.ApplicationException;
import com.paypal.exception.DaoException;
import com.paypal.model.Restaurant;

public class ZomatoDaoJdbcImpl implements ZomatoDao {
	
	private String driverName="com.mysql.jdbc.Driver";
	private String url="jdbc:mysql://localhost:8080/Zomato";
	private String username="root";
	private String password="SqlRoot3!";

	
	private Connection getConnection() throws ApplicationException {
		Connection conn = null;
		try {
			Class.forName(driverName);
			conn = DriverManager.getConnection(url, username, password);
		} catch (SQLException e) {
			e.printStackTrace();
			throw new ApplicationException();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			throw new ApplicationException();
		}
		return conn;
	}
	
	
	@Override
	public void addARestaurant(Restaurant restaurant) throws ApplicationException, DaoException  {
		Connection connection = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		String sql = "insert into RESTAURANT(name, address) values (?,?)";
		connection = getConnection();
		try {
			System.out.println("Adding.....");
			pstmt = connection.prepareStatement(sql);
			pstmt.setString(1, restaurant.getName());
			pstmt.setString(2, restaurant.getAddress());
			pstmt.executeUpdate();
			System.out.println("Added.......");
		} catch (Exception e) {
			e.printStackTrace();
			throw new DaoException();
		}
		finally {
			closeConnection(connection);
			closeStatement(pstmt);
			closeResultSet(rs);
		}
	}

	private void closeResultSet(ResultSet rs) throws ApplicationException {
		if (rs != null) {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
				throw new ApplicationException();
			}
		}
	}


	private void closeStatement(PreparedStatement pstmt) throws ApplicationException {
		if (pstmt != null) {
			try {
				pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
				throw new ApplicationException();
			}
		}
	}

	private void closeConnection(Connection connection) throws ApplicationException {
		if (connection != null) {
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
				throw new ApplicationException();
			}
		}
	}

	
}
