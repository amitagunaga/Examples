package com.paypal.web;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.paypal.dao.ZomatoDao;
import com.paypal.dao.ZomatoDaoJdbcImpl;
import com.paypal.exception.ApplicationException;
import com.paypal.exception.DaoException;
import com.paypal.model.Restaurant;

/**
 * Servlet implementation class FrontControllerServlet
 */
@WebServlet("/FrontControllerServlet")
public class FrontControllerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private static final String GET_ADD_RESTAURANT_FORM="addRestaurantForm.action";
	private static final String ADD_RESTAURANT_TO_DB="addRestaurantToDB.action";
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FrontControllerServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		process(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		process(request, response);
	}

	private void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String uri =  request.getRequestURI();
		if(uri.endsWith(GET_ADD_RESTAURANT_FORM)) {
			getAddRestaurantFormAction(request,response);
		}
		else if(uri.endsWith(ADD_RESTAURANT_TO_DB)) {
			getAddARestaurantToDBAction(request, response);
		}
	}
	
	private void getAddRestaurantFormAction(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String forwardPath = "addRestaurantForm.jsp";
		RequestDispatcher rd = request.getRequestDispatcher(forwardPath);
		rd.forward(request, response);
	}
	private void getAddARestaurantToDBAction(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ZomatoDao dao = new ZomatoDaoJdbcImpl();
		String forwardPath = "successPage.jsp";
		
		Restaurant restaurant = new Restaurant();
		restaurant.setName(request.getParameter("name"));
		restaurant.setAddress(request.getParameter("address"));
		
		try {
			dao.addARestaurant(restaurant);
		} catch (ApplicationException e) {
			e.printStackTrace();
			forwardPath = "errorPage.jsp";
			request.setAttribute("errorMess", e.getMessage());
		} catch (DaoException e) {
			e.printStackTrace();
			forwardPath = "errorPage.jsp";
			request.setAttribute("errorMess", e.getMessage());
		}
		request.setAttribute("successMess", "Restaurant "+restaurant.getName()+" successfully added");
		RequestDispatcher rd = request.getRequestDispatcher(forwardPath);
		rd.forward(request, response);
	}
}
