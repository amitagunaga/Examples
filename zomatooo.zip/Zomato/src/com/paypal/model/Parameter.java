package com.paypal.model;

public class Parameter {

}
