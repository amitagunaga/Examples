package com.paypal.model;

public class Ratings {
	private int ratingsId;
	//private String 
}
